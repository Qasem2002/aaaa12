<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تأميني المنصة الأولى لمقارنة أسعار تأمين المركبات والطبي وسفر وأخطاء طبية اونلاين في السعودية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS (bundle includes Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: "Cairo", serif;
            direction: rtl;
        }

        a {
            text-decoration: none;
        }

        /* body {
            height: 2000vh;
        }
         */

        .bacOne {
            background-color: #0088eb;
        }

        .fa-solid,
        label {
            color: rgb(153, 153, 153);
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        .fa-solid.active {
            color: rgb(194, 77, 141) !important;
        }

        .text-primary {
            color: #0088eb !important;
        }

        .text-muted {
            color: rgb(153, 153, 153) !important;
        }

        ::placeholder {
            color: #d2d6da !important;
        }

        .bg-two {
            background-color: #0088eb;
        }

        .form-check-input:checked {
            background-color:#76b740 !important;
            /* Bootstrap primary color or your custom color */
            border-color:#76b740;
        }

        /* Optional: Change the check mark dot color (on some browsers) */

        .form-check-input {
            width: 1.1em;
            height: 1.1em;
            border: 1px solid gray;
            /* Blue border, 2px thick */
        }

        .group {
            display: flex;
            align-items: center;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            height: 40px;
        }

        .bg-one {
            background-color: #0088eb;
            height: 40px;
            color: #f8f9fa;
        }

        .bg-o-two {
            height: 40px;
            height: 40px;
            background-color: rgb(240, 240, 240);
            color: rgb(153, 153, 153) !important;
        }

        .bg-a-two {
            height: 40px;
            background-color: rgb(230, 228, 228);
            color: rgb(153, 153, 153) !important;
        }

        .forShow {
            display: flex;
            gap: 10px;
        }

        .ajamaclas {
            display: flex;
            justify-content: start;
            align-items: center;
        }

        .btn-primary {
            background-color: #0088eb;
            border-color: #0088eb;
        }

        .btn-primary {
            background-color: #149ADE !important;
            border-color: #149ADE !important;
            border-radius: 8px !important;
            font-weight: 700 !important;
            z-index: 1 !important;
        }

        .btn-primary-no {
            background-color: #fff !important;
            border-color: #c3c2cb !important;
            border-radius: 8px !important;
            font-weight: 700 !important;
        }

        .hide {
            display: none !important;
        }

        .show {
            display: block !important;
        }

        input[type=checkbox] {
            width: 22px;
            height: 22px;
        }

        .tcik {
            text-align: center;
            /* background-color: #fff6e0;
            border-radius: 15px; */
        }

        .det {
            background: linear-gradient(180deg, #e4f5fe, #fff);
            border: 1px solid #149ade;
        }

        .chc {
            padding: 3px 5px;
            border-radius: 10px;
        }

        .success {
            color: #7fd884;
            background-color: rgba(127, 216, 132, .2);
        }

        .wrong {
            color: #e4856d;
            background-color: rgba(228, 133, 109, .2);
        }

        .btn-primary {
            background-color: #0088eb;
            border-color: #0088eb;
        }
    </style>
</head>

<body class="bg-light">

    <nav class="d-flex justify-content-center py-2 shadow-sm">
        <a href="index.php">
            <img src="./assets/tamini-removebg-preview.png" width="150"  alt="">
        </a>
    </nav>

    <div class="container mt-5" style="margin-bottom: 100px;">
        <form action="payment.php" method="post">
            <input type="hidden" name="status" value="5">
            <div class="row d-flex justify-content-center" id="insuranceDetails">
                <div class="bg-white rounded shadow-sm p-3 mb-4">
                    <div class="text-center">
                        <img src="./assets/<?php echo htmlspecialchars($_SESSION['image']); ?>" width="120" alt="User Image">
                        <!-- <hr> -->
                    </div>
                    <!-- <div>
                        <h6 class="fw-bold">تأمين مع</h6>
                        
                        <p style="font-size: 14px;" class="mt-1 ps-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#76b456" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"></path>
                            </svg> 
                        </p>
                        
                    </div> -->
                </div>
                <div class="bg-white rounded shadow-sm p-3 mb-4">
                    <div class="d-flex">
                        <small class="fw-bold w-50">
                            تاريخ بدء الوثيقة
                        </small>
                        <small class="mx-auto w-50 text-center"><?php echo $_SESSION['date']; ?></small>
                    </div>
                    <?php
                    // Check if data is submitted
                    if ($_SESSION['type'] == 1) {
                        echo '<div class="d-flex mt-1">
                        <small class="fw-bold w-50">
                            رقم الهوية
                        </small>
                        <small class="mx-auto w-50 text-center">' . $_SESSION['ssn'] . '</small>
                    </div>';

                        echo '<div class="d-flex mt-1">
                        <small class="fw-bold w-50">
                            سنة الصنع
                        </small>
                        <small class="mx-auto w-50 text-center">' . $_SESSION['createdYear'] . '</small>
                    </div>';
                    }

                    if ($_SESSION['type'] == 2) {
                        echo '<div class="d-flex mt-1">
                        <small class="fw-bold w-50">
                            اسم الشركة
                        </small>
                        <small class="mx-auto w-50 text-center">' . $_SESSION['company'] . '</small>
                    </div>';

                        echo '<div class="d-flex mt-1">
                        <small class="fw-bold w-50">
                            رقم السجل التجاري
                        </small>
                        <small class="mx-auto w-50 text-center">' . $_SESSION['comNum'] . '</small>
                    </div>';
                    }

                    if ($_SESSION['type'] == 3) {
                         echo '<div class="d-flex mt-1">
                        <small class="fw-bold w-50">
                            رقم الهوية
                        </small>
                        <small class="mx-auto w-50 text-center">' . $_SESSION['ssn'] . '</small>
                    </div>';
                    }

                    if ($_SESSION['type'] == 4) {
                         echo '<div class="d-flex mt-1">
                        <small class="fw-bold w-50">
                            تاريخ انتهاء الوثيقة
                        </small>
                        <small class="mx-auto w-50 text-center">' . $_SESSION['date2'] . '</small>
                    </div>';
                    }
                    ?>
                    <div class="d-flex mt-1">
                        <small class="fw-bold w-50">
                            الرقم المرجعي للتسعيرة </small>
                        <small class="mx-auto w-25 text-center"> 1703987910</small>
                    </div>
                </div>
                <div class="det p-3 mb-4 shadow-sm">
                    <h5 class="fw-bold pb-3" style="color: #149ADE;border-bottom:1px solid #149ADE;">التفاصيل</h5>
                    <div class="d-flex justify-content-between">
                        <small style="font-size: 11px;" class="fw-bold">
                            المجموع الجزئي </small>
                        <small class="w-25 fw-bold"><?php echo (float)$_SESSION['totalprice'] - ((float)$_SESSION['totalprice'] * 0.15); ?> ر.س</small>
                    </div>
                    <div class="d-flex justify-content-between">
                        <small style="font-size: 11px;" class="fw-bold">
                            ضريبة القيمة المضافة (15.00%) </small>
                        <small class="w-25 fw-bold"><?php echo (float)$_SESSION['totalprice'] * 0.15; ?> ر.س</small>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <small style="font-size: 16px;" class="fw-bold">
                            المبلغ الإجمالي </small>
                        <small class="w-25 fw-bold" style="font-size: 14px;"><span><?php echo (float)$_SESSION['totalprice']; ?></span> ر.س</small>
                    </div>
                    <small style="font-size: 9px;"> شامل جميع الضرائب و الرسوم و 4.00% عمولة الوسيط</small>
                </div>
            </div>
            <div class="text-center">
                <button type="submit" name="send" class="btn btn-primary w-75 text-light fw-bold mb-5" style="height: 45px !important; border-radius: 12px; font-size: 18px !important;">ادفع الآن</button>
            </div>
        </form>
    </div>



    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.getElementById('butSubm');

            // Listen to input events on all form fields
            form.addEventListener('input', function() {
                if (form.checkValidity()) {
                    submitBtn.disabled = false;
                } else {
                    submitBtn.disabled = true;
                }
            });

            // Also check on page load in case browser autofills
            if (form.checkValidity()) {
                submitBtn.disabled = false;
            } else {
                submitBtn.disabled = true;
            }
        });
    </script>
</body>

</html>