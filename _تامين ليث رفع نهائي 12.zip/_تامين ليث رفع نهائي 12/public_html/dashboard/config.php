<?php

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** MySQL database username */

define('DB_USER', 'u294837790_ac');

/** MySQL database password */

define('DB_PASSWORD', 'abdAB900');

/** MySQL database name */

define('DB_NAME', 'u294837790_ac');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE','');

define('CAN_REGISTER', 'none');
define('DEFAULT_ROLE', 'member');

// For development only!!
define('SECURE', false);

define('DEBUG', true);


?>