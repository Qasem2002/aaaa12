
<?php
$DB_HOST='localhost';
$DB_USER='u294837790_ac';
$DB_PASSWORD="abdAB900";

$DB_NAME="u294837790_ac";

         $con=mysqli_connect($DB_HOST,$DB_USER,$DB_PASSWORD,$DB_NAME);
         if(!$con){ echo "<script>alert('NO CONNECTION')</script>"; die();}
	
?>